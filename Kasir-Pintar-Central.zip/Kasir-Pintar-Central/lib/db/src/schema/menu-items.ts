import { createInsertSchema } from "drizzle-zod";
import { integer, numeric, pgTable, serial, text, timestamp, uniqueIndex } from "drizzle-orm/pg-core";
import { z } from "zod/v4";

export const menuItemsTable = pgTable(
  "kasir_menu_items",
  {
    id: serial("id").primaryKey(),
    name: text("name").notNull(),
    sellingPrice: integer("selling_price").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [uniqueIndex("kasir_menu_items_name_unique").on(table.name)],
);

export const menuItemRecipesTable = pgTable(
  "kasir_menu_item_recipes",
  {
    id: serial("id").primaryKey(),
    menuItemId: integer("menu_item_id")
      .notNull()
      .references(() => menuItemsTable.id, { onDelete: "cascade" }),
    inventoryId: integer("inventory_id").notNull(),
    quantity: numeric("quantity", { precision: 14, scale: 3, mode: "number" }).notNull(),
  },
  (table) => [
    uniqueIndex("kasir_menu_recipe_inventory_unique").on(table.menuItemId, table.inventoryId),
  ],
);

export const insertMenuItemSchema = createInsertSchema(menuItemsTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const insertMenuItemRecipeSchema = createInsertSchema(menuItemRecipesTable).omit({
  id: true,
});

export type InsertMenuItem = z.infer<typeof insertMenuItemSchema>;
export type InsertMenuItemRecipe = z.infer<typeof insertMenuItemRecipeSchema>;
export type MenuItem = typeof menuItemsTable.$inferSelect;
export type MenuItemRecipe = typeof menuItemRecipesTable.$inferSelect;
