import { createInsertSchema } from "drizzle-zod";
import { boolean, date, index, integer, numeric, pgTable, serial, text, timestamp, uniqueIndex } from "drizzle-orm/pg-core";
import { z } from "zod/v4";

export const kasirSalesTable = pgTable(
  "kasir_sales",
  {
    id: serial("id").primaryKey(),
    orderNumber: text("order_number").notNull(),
    itemsSummary: text("items_summary").notNull(),
    amount: integer("amount").notNull(),
    ingredientCost: integer("ingredient_cost").notNull(),
    paymentMethod: text("payment_method").notNull(),
    status: text("status").notNull().default("Selesai"),
    saleDate: date("sale_date", { mode: "string" }).notNull(),
    idempotencyKey: text("idempotency_key").notNull(),
    isDemo: boolean("is_demo").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [
    uniqueIndex("kasir_sales_order_number_unique").on(table.orderNumber),
    uniqueIndex("kasir_sales_idempotency_key_unique").on(table.idempotencyKey),
    index("kasir_sales_date_idx").on(table.saleDate),
  ],
);

export const saleInventoryUsagesTable = pgTable(
  "kasir_sale_inventory_usages",
  {
    id: serial("id").primaryKey(),
    saleId: integer("sale_id")
      .notNull()
      .references(() => kasirSalesTable.id, { onDelete: "cascade" }),
    inventoryId: integer("inventory_id").notNull(),
    quantity: numeric("quantity", { precision: 14, scale: 3, mode: "number" }).notNull(),
    unitCost: numeric("unit_cost", { precision: 14, scale: 4, mode: "number" }).notNull(),
  },
  (table) => [
    uniqueIndex("kasir_sale_usage_inventory_unique").on(table.saleId, table.inventoryId),
    index("kasir_sale_usage_inventory_idx").on(table.inventoryId),
  ],
);

export const insertKasirSaleSchema = createInsertSchema(kasirSalesTable).omit({
  id: true,
  createdAt: true,
});
export const insertSaleInventoryUsageSchema = createInsertSchema(saleInventoryUsagesTable).omit({
  id: true,
});

export type InsertKasirSale = z.infer<typeof insertKasirSaleSchema>;
export type InsertSaleInventoryUsage = z.infer<typeof insertSaleInventoryUsageSchema>;
export type KasirSale = typeof kasirSalesTable.$inferSelect;
export type SaleInventoryUsage = typeof saleInventoryUsagesTable.$inferSelect;
