import { index, jsonb, pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";

export const restaurantRecordsTable = pgTable(
  "restaurant_records",
  {
    id: serial("id").primaryKey(),
    kind: text("kind").notNull(),
    data: jsonb("data").$type<Record<string, unknown>>().notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [index("restaurant_records_kind_idx").on(table.kind)],
);

export type RestaurantRecord = typeof restaurantRecordsTable.$inferSelect;
