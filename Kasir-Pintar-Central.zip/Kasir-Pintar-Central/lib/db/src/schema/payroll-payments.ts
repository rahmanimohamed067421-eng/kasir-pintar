import {
  boolean,
  date,
  integer,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";

export const payrollPaymentsTable = pgTable(
  "payroll_payments",
  {
    id: serial("id").primaryKey(),
    employeeId: integer("employee_id").notNull(),
    amount: integer("amount").notNull(),
    period: text("period").notNull(),
    paymentDate: date("payment_date", { mode: "string" }).notNull(),
    status: text("status").notNull(),
    isDemo: boolean("is_demo").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [
    uniqueIndex("payroll_employee_period_unique").on(
      table.employeeId,
      table.period,
    ),
  ],
);

export type PayrollPayment = typeof payrollPaymentsTable.$inferSelect;
