import { asc, desc, eq } from "drizzle-orm";
import {
  db,
  kasirSalesTable,
  payrollPaymentsTable,
  restaurantRecordsTable,
} from "@workspace/db";

export type RestaurantData = Record<string, unknown>;
export type LegacyRecord = { id: number; data: RestaurantData };

export function isDemoData(data: RestaurantData): boolean {
  return typeof data.isDemo === "boolean" ? data.isDemo : true;
}

export async function listRestaurantRecords(kind: string): Promise<LegacyRecord[]> {
  const rows = await db
    .select()
    .from(restaurantRecordsTable)
    .where(eq(restaurantRecordsTable.kind, kind))
    .orderBy(asc(restaurantRecordsTable.id));
  return rows.map((row) => ({ id: row.id, data: row.data }));
}

type FinanceData = {
  sales: (typeof kasirSalesTable.$inferSelect)[];
  expenses: LegacyRecord[];
  payroll: (typeof payrollPaymentsTable.$inferSelect)[];
  inventory: LegacyRecord[];
  legacySales: LegacyRecord[];
};

type PeriodTotals = {
  revenue: number;
  ingredientCost: number;
  grossProfit: number;
  expenses: number;
  profit: number;
  orderCount: number;
};

function isInventoryPurchase(expense: RestaurantData): boolean {
  if (expense.expenseType === "inventory") return true;
  const category = String(expense.category ?? "").toLocaleLowerCase("id-ID");
  return ["bahan baku", "pembelian bahan", "persediaan", "inventory", "ingredient"]
    .some((term) => category.includes(term));
}

function isPayrollExpense(expense: RestaurantData): boolean {
  const category = String(expense.category ?? "").trim().toLocaleLowerCase("id-ID");
  return ["gaji", "upah", "salary", "payroll"].some((term) => category === term || category.startsWith(`${term} `));
}

async function loadFinanceData(): Promise<FinanceData> {
  const [sales, expenses, payroll, inventory, legacySales] = await Promise.all([
    db.select().from(kasirSalesTable).orderBy(desc(kasirSalesTable.createdAt)),
    listRestaurantRecords("expense"),
    db.select().from(payrollPaymentsTable),
    listRestaurantRecords("inventory"),
    listRestaurantRecords("sale"),
  ]);
  return { sales, expenses, payroll, inventory, legacySales };
}

function makeLegacySale(record: LegacyRecord) {
  const data = record.data;
  const createdAt = String(data.createdAt ?? "");
  return {
    id: record.id,
    orderNumber: String(data.orderNumber ?? `DEMO-${record.id}`),
    itemsSummary: String(data.itemsSummary ?? "Transaksi lama"),
    amount: Number(data.amount ?? 0),
    ingredientCost: null,
    grossProfit: null,
    paymentMethod: String(data.paymentMethod ?? "—"),
    status: String(data.status ?? "Selesai"),
    createdAt,
    saleDate: createdAt.slice(0, 10),
    isDemo: isDemoData(data),
  };
}

export function salesForApi(data: Pick<FinanceData, "sales" | "legacySales">) {
  const savedSales = data.sales.map((sale) => ({
    id: sale.id,
    orderNumber: sale.orderNumber,
    itemsSummary: sale.itemsSummary,
    amount: sale.amount,
    ingredientCost: sale.ingredientCost,
    grossProfit: sale.amount - sale.ingredientCost,
    paymentMethod: sale.paymentMethod,
    status: sale.status,
    createdAt: sale.createdAt.toISOString(),
    saleDate: sale.saleDate,
    isDemo: sale.isDemo,
  }));
  return [...savedSales, ...data.legacySales.map(makeLegacySale)]
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

function totalForPeriod(data: FinanceData, startDate: string, endDate: string): PeriodTotals {
  const sales = data.sales.filter(
    (sale) => !sale.isDemo && sale.status === "Selesai" && sale.saleDate >= startDate && sale.saleDate < endDate,
  );
  const expenses = data.expenses.filter(({ data: expense }) => {
    const date = String(expense.date ?? "");
    return !isDemoData(expense)
      && !isInventoryPurchase(expense)
      && !isPayrollExpense(expense)
      && date >= startDate
      && date < endDate;
  });
  const payroll = data.payroll.filter(
    (payment) => !payment.isDemo && payment.status === "paid" && payment.paymentDate >= startDate && payment.paymentDate < endDate,
  );
  const revenue = sales.reduce((total, sale) => total + sale.amount, 0);
  const ingredientCost = sales.reduce((total, sale) => total + sale.ingredientCost, 0);
  const grossProfit = revenue - ingredientCost;
  const operatingExpenses = expenses.reduce((total, { data: expense }) => total + Number(expense.amount ?? 0), 0);
  const paidPayroll = payroll.reduce((total, payment) => total + payment.amount, 0);
  return {
    revenue,
    ingredientCost,
    grossProfit,
    expenses: operatingExpenses + paidPayroll,
    profit: grossProfit - operatingExpenses - paidPayroll,
    orderCount: sales.length,
  };
}

function monthEndExclusive(month: string): string {
  const [year, monthNumber] = month.split("-").map(Number);
  const next = new Date(Date.UTC(year, monthNumber, 1));
  return `${next.getUTCFullYear()}-${String(next.getUTCMonth() + 1).padStart(2, "0")}-01`;
}

function shiftMonth(month: string, offset: number): string {
  const [year, monthNumber] = month.split("-").map(Number);
  const shifted = new Date(Date.UTC(year, monthNumber - 1 + offset, 1));
  return `${shifted.getUTCFullYear()}-${String(shifted.getUTCMonth() + 1).padStart(2, "0")}`;
}

export async function getKasirReports(date: string, month: string) {
  const data = await loadFinanceData();
  const daily = totalForPeriod(data, date, shiftDate(date, 1));
  const monthly = totalForPeriod(data, `${month}-01`, monthEndExclusive(month));
  return {
    dailyRevenue: daily.revenue,
    dailyIngredientCost: daily.ingredientCost,
    dailyGrossProfit: daily.grossProfit,
    dailyExpenses: daily.expenses,
    dailyProfit: daily.profit,
    monthlyRevenue: monthly.revenue,
    monthlyIngredientCost: monthly.ingredientCost,
    monthlyGrossProfit: monthly.grossProfit,
    monthlyExpenses: monthly.expenses,
    monthlyProfit: monthly.profit,
  };
}

export async function getKasirDashboard(date: string, month: string) {
  const data = await loadFinanceData();
  const daily = totalForPeriod(data, date, shiftDate(date, 1));
  const monthly = totalForPeriod(data, `${month}-01`, monthEndExclusive(month));
  const monthlyTrend = Array.from({ length: 6 }, (_, index) => {
    const key = shiftMonth(month, index - 5);
    const totals = totalForPeriod(data, `${key}-01`, monthEndExclusive(key));
    const [year, monthNumber] = key.split("-").map(Number);
    return {
      label: new Intl.DateTimeFormat("id-ID", { month: "short", timeZone: "UTC" })
        .format(new Date(Date.UTC(year, monthNumber - 1, 1))),
      revenue: totals.revenue,
      ingredientCost: totals.ingredientCost,
      grossProfit: totals.grossProfit,
      expenses: totals.expenses,
      profit: totals.profit,
    };
  });
  const lowStockCount = data.inventory.filter(({ data: item }) =>
    Number(item.quantity ?? 0) <= Number(item.minimum ?? 0),
  ).length;
  const recentSales = salesForApi(data).slice(0, 5);
  return {
    revenue: daily.revenue,
    ingredientCost: daily.ingredientCost,
    grossProfit: daily.grossProfit,
    expenses: daily.expenses,
    profit: daily.profit,
    orderCount: daily.orderCount,
    lowStockCount,
    recentSales,
    monthlyTrend,
    monthlyRevenue: monthly.revenue,
  };
}

function shiftDate(date: string, offsetDays: number): string {
  const [year, month, day] = date.split("-").map(Number);
  const shifted = new Date(Date.UTC(year, month - 1, day + offsetDays));
  return `${shifted.getUTCFullYear()}-${String(shifted.getUTCMonth() + 1).padStart(2, "0")}-${String(shifted.getUTCDate()).padStart(2, "0")}`;
}
