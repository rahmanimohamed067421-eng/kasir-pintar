import { Router, type IRouter } from "express";
import healthRouter from "./health";
import kasirRouter from "./kasir";
import menuSalesRouter from "./menu-sales";

const router: IRouter = Router();

router.use(healthRouter);
router.use(kasirRouter);
router.use(menuSalesRouter);

export default router;
