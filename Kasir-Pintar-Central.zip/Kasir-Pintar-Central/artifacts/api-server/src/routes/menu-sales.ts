import { randomUUID } from "node:crypto";
import { Router, type IRouter, type Response } from "express";
import { and, asc, eq, inArray } from "drizzle-orm";
import {
  db,
  kasirSalesTable,
  menuItemRecipesTable,
  menuItemsTable,
  restaurantRecordsTable,
  saleInventoryUsagesTable,
} from "@workspace/db";
import {
  CreateMenuItemBody,
  CreateMenuItemResponse,
  CreateSaleBody,
  CreateSaleResponse,
  GetMenuItemsResponse,
  GetSalesResponse,
  UpdateMenuItemBody,
  UpdateMenuItemParams,
  UpdateMenuItemResponse,
  UpdateSaleStatusBody,
  UpdateSaleStatusParams,
  UpdateSaleStatusResponse,
} from "@workspace/api-zod";
import { isDemoData, listRestaurantRecords, salesForApi } from "../lib/kasir-finance";

const router: IRouter = Router();
type RecipeInput = { inventoryId: number; quantity: number };
type SaleLineInput = { menuItemId: number; quantity: number };
type InventoryData = Record<string, unknown>;

function parseBody<T>(
  schema: {
    safeParse: (body: unknown) =>
      | { success: true; data: T }
      | { success: false; error: { message: string } };
  },
  body: unknown,
  res: Response,
): T | null {
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return null;
  }
  return parsed.data;
}

function isUniqueConflict(error: unknown): boolean {
  return typeof error === "object" && error !== null && "code" in error && error.code === "23505";
}

function roundedRupiah(value: number): number {
  return Math.round(value);
}

function summarizeSale(sale: typeof kasirSalesTable.$inferSelect) {
  return {
    id: sale.id,
    orderNumber: sale.orderNumber,
    itemsSummary: sale.itemsSummary,
    amount: sale.amount,
    ingredientCost: sale.ingredientCost,
    grossProfit: sale.amount - sale.ingredientCost,
    paymentMethod: sale.paymentMethod,
    status: sale.status,
    createdAt: sale.createdAt.toISOString(),
    saleDate: sale.saleDate,
    isDemo: sale.isDemo,
  };
}

function positiveRecipe(recipe: RecipeInput[]): string | null {
  if (recipe.length === 0) return "Resep harus memiliki setidaknya satu bahan.";
  const ids = new Set<number>();
  for (const row of recipe) {
    if (!Number.isInteger(row.inventoryId) || row.inventoryId <= 0) return "Pilih bahan stok yang valid.";
    if (!Number.isFinite(row.quantity) || row.quantity <= 0) return "Takaran resep harus lebih besar dari nol.";
    if (ids.has(row.inventoryId)) return "Bahan yang sama hanya boleh muncul satu kali dalam resep.";
    ids.add(row.inventoryId);
  }
  return null;
}

async function validateRecipeInventory(
  recipe: RecipeInput[],
  queryable: typeof db | Parameters<Parameters<typeof db.transaction>[0]>[0] = db,
): Promise<{ inventory: Map<number, { data: InventoryData; id: number }> } | { error: string }> {
  const recipeError = positiveRecipe(recipe);
  if (recipeError) return { error: recipeError };
  const ids = recipe.map((row) => row.inventoryId);
  const rows = await queryable
    .select()
    .from(restaurantRecordsTable)
    .where(and(inArray(restaurantRecordsTable.id, ids), eq(restaurantRecordsTable.kind, "inventory")));
  const inventory = new Map(rows.map((row) => [row.id, { id: row.id, data: row.data as InventoryData }]));
  if (inventory.size !== ids.length) return { error: "Satu atau lebih bahan stok tidak ditemukan. Muat ulang lalu periksa resep." };
  for (const { data } of inventory.values()) {
    if (!Number.isFinite(Number(data.costPerUnit)) || Number(data.costPerUnit) < 0) {
      return { error: "Harga salah satu bahan tidak valid. Perbarui biaya bahan sebelum menyimpan resep." };
    }
  }
  return { inventory };
}

function menuItemResponse(
  item: typeof menuItemsTable.$inferSelect,
  recipeRows: (typeof menuItemRecipesTable.$inferSelect)[],
  inventory: Map<number, { data: InventoryData; id: number }>,
) {
  const recipe = recipeRows
    .filter((row) => row.menuItemId === item.id)
    .map((row) => {
      const stock = inventory.get(row.inventoryId);
      const stockData = stock?.data ?? {};
      return {
        inventoryId: row.inventoryId,
        ingredientName: String(stockData.name ?? "Bahan tidak ditemukan"),
        unit: String(stockData.unit ?? ""),
        quantity: Number(row.quantity),
        costPerUnit: Number(stockData.costPerUnit ?? 0),
        isDemo: stock ? isDemoData(stock.data) : true,
      };
    });
  const ingredientCost = roundedRupiah(recipe.reduce((total, row) => total + row.quantity * row.costPerUnit, 0));
  return {
    id: item.id,
    name: item.name,
    sellingPrice: item.sellingPrice,
    recipe,
    ingredientCost,
    grossProfit: item.sellingPrice - ingredientCost,
    foodCostPercent: item.sellingPrice === 0 ? 0 : ingredientCost / item.sellingPrice * 100,
    usesDemoInventory: recipe.some((row) => row.isDemo),
  };
}

async function getMenuItemResponse(id: number) {
  const [item] = await db.select().from(menuItemsTable).where(eq(menuItemsTable.id, id));
  if (!item) return null;
  const [recipeRows, stocks] = await Promise.all([
    db.select().from(menuItemRecipesTable).where(eq(menuItemRecipesTable.menuItemId, id)).orderBy(asc(menuItemRecipesTable.inventoryId)),
    listRestaurantRecords("inventory"),
  ]);
  const inventory = new Map(stocks.map((row) => [row.id, { id: row.id, data: row.data }]));
  return menuItemResponse(item, recipeRows, inventory);
}

router.get("/kasir/menu-items", async (_req, res): Promise<void> => {
  const [items, recipeRows, stocks] = await Promise.all([
    db.select().from(menuItemsTable).orderBy(asc(menuItemsTable.name)),
    db.select().from(menuItemRecipesTable).orderBy(asc(menuItemRecipesTable.inventoryId)),
    listRestaurantRecords("inventory"),
  ]);
  const inventory = new Map(stocks.map((row) => [row.id, { id: row.id, data: row.data }]));
  res.json(GetMenuItemsResponse.parse(items.map((item) => menuItemResponse(item, recipeRows, inventory))));
});

router.post("/kasir/menu-items", async (req, res): Promise<void> => {
  const data = parseBody(CreateMenuItemBody, req.body, res);
  if (!data) return;
  const name = data.name.trim();
  if (!name) {
    res.status(400).json({ error: "Nama menu wajib diisi." });
    return;
  }
  const validated = await validateRecipeInventory(data.recipe);
  if ("error" in validated) {
    res.status(400).json({ error: validated.error });
    return;
  }
  try {
    const created = await db.transaction(async (tx) => {
      const [item] = await tx.insert(menuItemsTable).values({
        name,
        sellingPrice: data.sellingPrice,
      }).returning();
      await tx.insert(menuItemRecipesTable).values(data.recipe.map((row) => ({
        menuItemId: item.id,
        inventoryId: row.inventoryId,
        quantity: row.quantity,
      })));
      return item;
    });
    const response = await getMenuItemResponse(created.id);
    res.status(201).json(CreateMenuItemResponse.parse(response));
  } catch (error) {
    if (isUniqueConflict(error)) {
      res.status(409).json({ error: "Nama menu sudah digunakan. Gunakan nama lain." });
      return;
    }
    throw error;
  }
});

router.patch("/kasir/menu-items/:id", async (req, res): Promise<void> => {
  const params = UpdateMenuItemParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const data = parseBody(UpdateMenuItemBody, req.body, res);
  if (!data) return;
  if (Object.keys(data).length === 0) {
    res.status(400).json({ error: "Pilih informasi menu yang ingin diperbarui." });
    return;
  }
  if (data.name !== undefined && !data.name.trim()) {
    res.status(400).json({ error: "Nama menu wajib diisi." });
    return;
  }
  if (data.recipe) {
    const validated = await validateRecipeInventory(data.recipe);
    if ("error" in validated) {
      res.status(400).json({ error: validated.error });
      return;
    }
  }
  try {
    const result = await db.transaction(async (tx) => {
      const [existing] = await tx
        .select()
        .from(menuItemsTable)
        .where(eq(menuItemsTable.id, params.data.id))
        .for("update");
      if (!existing) return null;
      await tx.update(menuItemsTable).set({
        ...(data.name !== undefined ? { name: data.name.trim() } : {}),
        ...(data.sellingPrice !== undefined ? { sellingPrice: data.sellingPrice } : {}),
        updatedAt: new Date(),
      }).where(eq(menuItemsTable.id, existing.id));
      if (data.recipe) {
        await tx.delete(menuItemRecipesTable).where(eq(menuItemRecipesTable.menuItemId, existing.id));
        await tx.insert(menuItemRecipesTable).values(data.recipe.map((row) => ({
          menuItemId: existing.id,
          inventoryId: row.inventoryId,
          quantity: row.quantity,
        })));
      }
      return existing.id;
    });
    if (result === null) {
      res.status(404).json({ error: "Menu tidak ditemukan." });
      return;
    }
    const response = await getMenuItemResponse(result);
    res.json(UpdateMenuItemResponse.parse(response));
  } catch (error) {
    if (isUniqueConflict(error)) {
      res.status(409).json({ error: "Nama menu sudah digunakan. Gunakan nama lain." });
      return;
    }
    throw error;
  }
});

router.get("/kasir/sales", async (_req, res): Promise<void> => {
  const [sales, legacySales] = await Promise.all([
    db.select().from(kasirSalesTable).orderBy(asc(kasirSalesTable.id)),
    listRestaurantRecords("sale"),
  ]);
  res.json(GetSalesResponse.parse(salesForApi({ sales, legacySales })));
});

router.post("/kasir/sales", async (req, res): Promise<void> => {
  const data = parseBody(CreateSaleBody, req.body, res);
  if (!data) return;
  const duplicate = await db
    .select()
    .from(kasirSalesTable)
    .where(eq(kasirSalesTable.idempotencyKey, data.idempotencyKey));
  if (duplicate[0]) {
    res.status(200).json(CreateSaleResponse.parse(summarizeSale(duplicate[0])));
    return;
  }
  const lines = data.lines as SaleLineInput[];
  const uniqueMenuIds = [...new Set(lines.map((line) => line.menuItemId))].sort((a, b) => a - b);
  let result:
    | { sale: typeof kasirSalesTable.$inferSelect; created: boolean }
    | { error: string; insufficient?: boolean };
  try {
    result = await db.transaction(async (tx) => {
    const repeated = await tx.select().from(kasirSalesTable)
      .where(eq(kasirSalesTable.idempotencyKey, data.idempotencyKey));
    if (repeated[0]) return { sale: repeated[0], created: false as const };

    const menuRows = [];
    for (const id of uniqueMenuIds) {
      const [item] = await tx.select().from(menuItemsTable).where(eq(menuItemsTable.id, id)).for("share");
      if (item) menuRows.push(item);
    }
    if (menuRows.length !== uniqueMenuIds.length) {
      return { error: "Satu atau lebih menu tidak ditemukan. Muat ulang daftar menu." };
    }
    const recipeRows = await tx.select().from(menuItemRecipesTable)
      .where(inArray(menuItemRecipesTable.menuItemId, uniqueMenuIds))
      .orderBy(asc(menuItemRecipesTable.inventoryId));
    const recipeByMenu = new Map<number, typeof recipeRows>();
    for (const row of recipeRows) {
      const rows = recipeByMenu.get(row.menuItemId) ?? [];
      rows.push(row);
      recipeByMenu.set(row.menuItemId, rows);
    }
    for (const menu of menuRows) {
      if (!recipeByMenu.get(menu.id)?.length) return { error: `Menu ${menu.name} belum memiliki resep.` };
    }

    const usage = new Map<number, number>();
    const menuById = new Map(menuRows.map((item) => [item.id, item]));
    const summaryParts: string[] = [];
    let amount = 0;
    for (const line of lines) {
      const menu = menuById.get(line.menuItemId);
      if (!menu) return { error: "Menu tidak ditemukan." };
      amount += menu.sellingPrice * line.quantity;
      summaryParts.push(`${menu.name} (${line.quantity})`);
      for (const recipe of recipeByMenu.get(menu.id) ?? []) {
        usage.set(recipe.inventoryId, (usage.get(recipe.inventoryId) ?? 0) + Number(recipe.quantity) * line.quantity);
      }
    }

    const inventoryRows = new Map<number, { id: number; data: InventoryData }>();
    for (const inventoryId of [...usage.keys()].sort((a, b) => a - b)) {
      const [row] = await tx.select().from(restaurantRecordsTable)
        .where(and(eq(restaurantRecordsTable.id, inventoryId), eq(restaurantRecordsTable.kind, "inventory")))
        .for("update");
      if (!row) return { error: "Bahan resep tidak lagi tersedia di stok. Periksa menu dan persediaan." };
      inventoryRows.set(row.id, { id: row.id, data: row.data });
    }

    const retry = await tx.select().from(kasirSalesTable)
      .where(eq(kasirSalesTable.idempotencyKey, data.idempotencyKey));
    if (retry[0]) return { sale: retry[0], created: false as const };

    for (const [inventoryId, requiredQuantity] of usage) {
      const row = inventoryRows.get(inventoryId)!;
      const available = Number(row.data.quantity ?? 0);
      if (!Number.isFinite(available) || available + 1e-9 < requiredQuantity) {
        return {
          error: `Stok ${String(row.data.name ?? "bahan")} tidak cukup. Tersedia ${available} ${String(row.data.unit ?? "")}; dibutuhkan ${requiredQuantity} ${String(row.data.unit ?? "")}.`,
          insufficient: true,
        };
      }
    }

    let ingredientCostTotal = 0;
    let usesDemoInventory = false;
    for (const [inventoryId, requiredQuantity] of usage) {
      const row = inventoryRows.get(inventoryId)!;
      const unitCost = Number(row.data.costPerUnit ?? 0);
      if (!Number.isFinite(unitCost) || unitCost < 0) return { error: "Biaya salah satu bahan tidak valid." };
      ingredientCostTotal += requiredQuantity * unitCost;
      usesDemoInventory ||= isDemoData(row.data);
      await tx.update(restaurantRecordsTable).set({
        data: { ...row.data, quantity: Number((Number(row.data.quantity) - requiredQuantity).toFixed(3)) },
      }).where(and(eq(restaurantRecordsTable.id, inventoryId), eq(restaurantRecordsTable.kind, "inventory")));
    }
    const ingredientCost = roundedRupiah(ingredientCostTotal);
    const [sale] = await tx.insert(kasirSalesTable).values({
      orderNumber: `ORD-${randomUUID().slice(0, 8).toUpperCase()}`,
      itemsSummary: summaryParts.join(", "),
      amount,
      ingredientCost,
      paymentMethod: data.paymentMethod,
      status: "Selesai",
      saleDate: data.saleDate,
      idempotencyKey: data.idempotencyKey,
      isDemo: usesDemoInventory,
    }).returning();
    await tx.insert(saleInventoryUsagesTable).values([...usage].map(([inventoryId, quantity]) => ({
      saleId: sale.id,
      inventoryId,
      quantity,
      unitCost: Number(inventoryRows.get(inventoryId)!.data.costPerUnit ?? 0),
    })));
    return { sale, created: true as const };
    });
  } catch (error) {
    if (isUniqueConflict(error)) {
      const [existing] = await db.select().from(kasirSalesTable)
        .where(eq(kasirSalesTable.idempotencyKey, data.idempotencyKey));
      if (existing) {
        res.status(200).json(CreateSaleResponse.parse(summarizeSale(existing)));
        return;
      }
    }
    throw error;
  }

  if ("error" in result) {
    res.status(result.insufficient ? 409 : 400).json({ error: result.error });
    return;
  }
  res.status(result.created ? 201 : 200).json(CreateSaleResponse.parse(summarizeSale(result.sale)));
});

router.patch("/kasir/sales/:id", async (req, res): Promise<void> => {
  const params = UpdateSaleStatusParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const data = parseBody(UpdateSaleStatusBody, req.body, res);
  if (!data) return;
  const result = await db.transaction(async (tx) => {
    const [sale] = await tx.select().from(kasirSalesTable)
      .where(eq(kasirSalesTable.id, params.data.id))
      .for("update");
    if (!sale) return { notFound: true as const };
    if (sale.status !== "Selesai") {
      if (sale.status === (data.status === "cancelled" ? "Dibatalkan" : "Direfund")) {
        return { sale };
      }
      return { conflict: true as const };
    }
    const usages = await tx.select().from(saleInventoryUsagesTable)
      .where(eq(saleInventoryUsagesTable.saleId, sale.id))
      .orderBy(asc(saleInventoryUsagesTable.inventoryId));
    for (const usage of usages) {
      const [inventory] = await tx.select().from(restaurantRecordsTable)
        .where(and(
          eq(restaurantRecordsTable.id, usage.inventoryId),
          eq(restaurantRecordsTable.kind, "inventory"),
        ))
        .for("update");
      if (!inventory) throw new Error(`Inventory record ${usage.inventoryId} is missing for sale ${sale.id}`);
      await tx.update(restaurantRecordsTable).set({
        data: {
          ...inventory.data,
          quantity: Number((Number(inventory.data.quantity ?? 0) + Number(usage.quantity)).toFixed(3)),
        },
      }).where(eq(restaurantRecordsTable.id, usage.inventoryId));
    }
    const [updated] = await tx.update(kasirSalesTable)
      .set({ status: data.status === "cancelled" ? "Dibatalkan" : "Direfund" })
      .where(eq(kasirSalesTable.id, sale.id))
      .returning();
    return { sale: updated };
  });
  if ("notFound" in result) {
    res.status(404).json({ error: "Transaksi tidak ditemukan." });
    return;
  }
  if ("conflict" in result) {
    res.status(409).json({ error: "Transaksi ini sudah dibatalkan atau direfund." });
    return;
  }
  res.json(UpdateSaleStatusResponse.parse(summarizeSale(result.sale)));
});

export default router;
