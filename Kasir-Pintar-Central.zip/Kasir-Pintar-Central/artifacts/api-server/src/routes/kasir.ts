import { Router, type IRouter, type Response } from "express";
import { and, asc, desc, eq, ne } from "drizzle-orm";
import {
  db,
  payrollPaymentsTable,
  restaurantRecordsTable,
} from "@workspace/db";
import {
  CreateEmployeeBody,
  CreateEmployeeResponse,
  CreateExpenseBody,
  CreateExpenseResponse,
  CreateIngredientBody,
  CreateIngredientResponse,
  CreateInventoryItemBody,
  CreateInventoryItemResponse,
  GetEmployeesResponse,
  GetExpensesResponse,
  GetIngredientsResponse,
  GetInventoryResponse,
  GetKasirDashboardResponse,
  GetKasirDashboardQueryParams,
  GetReportsResponse,
  GetReportsQueryParams,
  GetPayrollPaymentsResponse,
  CreatePayrollPaymentBody,
  CreatePayrollPaymentResponse,
  UpdateEmployeeBody,
  UpdateEmployeeParams,
  UpdateEmployeeResponse,
  UpdatePayrollPaymentBody,
  UpdatePayrollPaymentParams,
  UpdatePayrollPaymentResponse,
  UpdateInventoryItemBody,
  UpdateInventoryItemParams,
  UpdateInventoryItemResponse,
} from "@workspace/api-zod";
import {
  getKasirDashboard,
  getKasirReports,
  isDemoData,
} from "../lib/kasir-finance";

const router: IRouter = Router();

type Kind = "ingredient" | "inventory" | "sale" | "expense" | "employee";
type RecordPayload = Record<string, unknown>;

async function listRecords(kind: Kind) {
  const rows = await db
    .select()
    .from(restaurantRecordsTable)
    .where(eq(restaurantRecordsTable.kind, kind))
    .orderBy(asc(restaurantRecordsTable.id));
  return rows.map((row) => ({ id: row.id, ...row.data })) as RecordPayload[];
}

async function insertRecord(kind: Kind, data: RecordPayload) {
  const [row] = await db
    .insert(restaurantRecordsTable)
    .values({ kind, data })
    .returning();
  return { id: row.id, ...row.data };
}

function parseBody<T>(
  schema: {
    safeParse: (body: unknown) =>
      | { success: true; data: T }
      | { success: false; error: { message: string } };
  },
  body: unknown,
  res: Response,
): T | null {
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return null;
  }
  return parsed.data as T;
}

function matchesIngredient(a: RecordPayload, b: RecordPayload): boolean {
  return String(a.name ?? "").trim().toLocaleLowerCase("id-ID") === String(b.name ?? "").trim().toLocaleLowerCase("id-ID")
    && String(a.unit ?? "").trim().toLocaleLowerCase("id-ID") === String(b.unit ?? "").trim().toLocaleLowerCase("id-ID");
}

router.get("/kasir/ingredients", async (_req, res): Promise<void> => {
  const [ingredients, inventory] = await Promise.all([
    listRecords("ingredient"),
    listRecords("inventory"),
  ]);
  const result = ingredients.map((ingredient) => {
    const linked = inventory.find((item) =>
      Number(ingredient.inventoryId) === Number(item.id) || matchesIngredient(ingredient, item),
    );
    return {
      ...ingredient,
      ...(linked ? { inventoryId: Number(linked.id), isDemo: isDemoData(linked) } : { isDemo: isDemoData(ingredient) }),
    };
  });
  res.json(GetIngredientsResponse.parse(result));
});

router.post("/kasir/ingredients", async (req, res): Promise<void> => {
  const data = parseBody(CreateIngredientBody, req.body, res);
  if (!data) return;
  const name = data.name.trim();
  const unit = data.unit.trim();
  if (!name || !unit) {
    res.status(400).json({ error: "Nama bahan dan satuan wajib diisi." });
    return;
  }
  const result = await db.transaction(async (tx) => {
    const inventoryRows = await tx.select().from(restaurantRecordsTable)
      .where(eq(restaurantRecordsTable.kind, "inventory"));
    let inventory = inventoryRows.find((row) => matchesIngredient({ name, unit }, row.data));
    if (inventory) {
      const nextData = { ...inventory.data, costPerUnit: data.costPerUnit };
      const [updated] = await tx.update(restaurantRecordsTable).set({ data: nextData })
        .where(eq(restaurantRecordsTable.id, inventory.id)).returning();
      inventory = updated;
    } else {
      const [created] = await tx.insert(restaurantRecordsTable).values({
        kind: "inventory",
        data: {
          name,
          unit,
          category: "Bahan baku",
          quantity: 0,
          minimum: 0,
          costPerUnit: data.costPerUnit,
          isDemo: false,
        },
      }).returning();
      inventory = created;
    }
    const ingredients = await tx.select().from(restaurantRecordsTable)
      .where(eq(restaurantRecordsTable.kind, "ingredient"));
    const existing = ingredients.find((row) =>
      Number(row.data.inventoryId) === inventory!.id || matchesIngredient({ name, unit }, row.data),
    );
    const ingredientData = {
      ...data,
      name,
      unit,
      inventoryId: inventory.id,
      isDemo: isDemoData(inventory.data),
    };
    if (existing) {
      const [updated] = await tx.update(restaurantRecordsTable).set({ data: ingredientData })
        .where(eq(restaurantRecordsTable.id, existing.id)).returning();
      return { id: updated.id, ...updated.data };
    }
    const [created] = await tx.insert(restaurantRecordsTable)
      .values({ kind: "ingredient", data: ingredientData }).returning();
    return { id: created.id, ...created.data };
  });
  res.status(201).json(CreateIngredientResponse.parse(result));
});

router.get("/kasir/inventory", async (_req, res): Promise<void> => {
  const result = await listRecords("inventory");
  res.json(GetInventoryResponse.parse(result.map((item) => ({ ...item, isDemo: isDemoData(item) }))));
});

router.post("/kasir/inventory", async (req, res): Promise<void> => {
  const data = parseBody(CreateInventoryItemBody, req.body, res);
  if (!data) return;
  const name = data.name.trim();
  const unit = data.unit.trim();
  if (!name || !unit) {
    res.status(400).json({ error: "Nama bahan dan satuan wajib diisi." });
    return;
  }
  const result = await db.transaction(async (tx) => {
    const inventoryRows = await tx.select().from(restaurantRecordsTable)
      .where(eq(restaurantRecordsTable.kind, "inventory"));
    if (inventoryRows.some((row) => matchesIngredient({ name, unit }, row.data))) return null;
    const [created] = await tx.insert(restaurantRecordsTable).values({
      kind: "inventory",
      data: { ...data, name, unit, isDemo: false },
    }).returning();
    const ingredients = await tx.select().from(restaurantRecordsTable)
      .where(eq(restaurantRecordsTable.kind, "ingredient"));
    const existing = ingredients.find((row) => matchesIngredient({ name, unit }, row.data));
    const ingredientData = {
      name,
      unit,
      costPerUnit: data.costPerUnit,
      inventoryId: created.id,
      isDemo: false,
    };
    if (existing) {
      await tx.update(restaurantRecordsTable).set({ data: ingredientData })
        .where(eq(restaurantRecordsTable.id, existing.id));
    } else {
      await tx.insert(restaurantRecordsTable).values({ kind: "ingredient", data: ingredientData });
    }
    return { id: created.id, ...created.data };
  });
  if (!result) {
    res.status(409).json({ error: "Bahan dengan nama dan satuan ini sudah ada. Perbarui jumlah stok yang sudah terdaftar." });
    return;
  }
  res.status(201).json(CreateInventoryItemResponse.parse(result));
});

router.patch("/kasir/inventory/:id", async (req, res): Promise<void> => {
  const params = UpdateInventoryItemParams.safeParse(req.params);
  const body = UpdateInventoryItemBody.safeParse(req.body);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  const result = await db.transaction(async (tx) => {
    const [row] = await tx.select().from(restaurantRecordsTable)
      .where(and(eq(restaurantRecordsTable.id, params.data.id), eq(restaurantRecordsTable.kind, "inventory")))
      .for("update");
    if (!row) return null;
    const nextData = { ...row.data, ...body.data };
    const [updated] = await tx.update(restaurantRecordsTable).set({ data: nextData })
      .where(eq(restaurantRecordsTable.id, params.data.id)).returning();
    if (body.data.costPerUnit !== undefined) {
      const ingredients = await tx.select().from(restaurantRecordsTable)
        .where(eq(restaurantRecordsTable.kind, "ingredient"));
      for (const ingredient of ingredients) {
        if (Number(ingredient.data.inventoryId) === row.id || matchesIngredient(row.data, ingredient.data)) {
          await tx.update(restaurantRecordsTable).set({
            data: { ...ingredient.data, costPerUnit: body.data.costPerUnit },
          }).where(eq(restaurantRecordsTable.id, ingredient.id));
        }
      }
    }
    return { id: updated.id, ...updated.data };
  });
  if (!result) {
    res.status(404).json({ error: "Barang tidak ditemukan" });
    return;
  }
  res.json(UpdateInventoryItemResponse.parse({ ...result, isDemo: isDemoData(result) }));
});

router.get("/kasir/expenses", async (_req, res): Promise<void> => {
  const rows = await listRecords("expense");
  const sorted = rows.sort((a, b) => String(b["date"]).localeCompare(String(a["date"])));
  res.json(GetExpensesResponse.parse(sorted.map((item) => ({ ...item, isDemo: isDemoData(item) }))));
});

router.post("/kasir/expenses", async (req, res): Promise<void> => {
  const data = parseBody(CreateExpenseBody, req.body, res);
  if (!data) return;
  res.status(201).json(CreateExpenseResponse.parse(await insertRecord("expense", {
    ...data as RecordPayload,
    expenseType: data.expenseType ?? "operational",
    isDemo: false,
  })));
});

router.get("/kasir/employees", async (_req, res): Promise<void> => {
  const employees = await listRecords("employee");
  res.json(GetEmployeesResponse.parse(employees.map((employee) => ({
    ...employee,
    isDemo: isDemoData(employee),
  }))));
});

router.post("/kasir/employees", async (req, res): Promise<void> => {
  const data = parseBody(CreateEmployeeBody, req.body, res);
  if (!data) return;
  res.status(201).json(CreateEmployeeResponse.parse(await insertRecord("employee", {
    ...data as RecordPayload,
    status: "Aktif",
    isDemo: false,
  })));
});

router.patch("/kasir/employees/:id", async (req, res): Promise<void> => {
  const params = UpdateEmployeeParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const data = parseBody(UpdateEmployeeBody, req.body, res);
  if (!data || Object.keys(data).length === 0) {
    if (data) res.status(400).json({ error: "Pilih setidaknya satu informasi untuk diperbarui." });
    return;
  }
  const [row] = await db
    .select()
    .from(restaurantRecordsTable)
    .where(and(eq(restaurantRecordsTable.id, params.data.id), eq(restaurantRecordsTable.kind, "employee")));
  if (!row) {
    res.status(404).json({ error: "Karyawan tidak ditemukan" });
    return;
  }
  const [updated] = await db
    .update(restaurantRecordsTable)
    .set({ data: { ...row.data, ...data } })
    .where(eq(restaurantRecordsTable.id, params.data.id))
    .returning();
  res.json(UpdateEmployeeResponse.parse({ id: updated.id, ...updated.data }));
});

function isUniqueConflict(error: unknown): boolean {
  return typeof error === "object" && error !== null && "code" in error && error.code === "23505";
}

function payrollResponse(
  row: typeof payrollPaymentsTable.$inferSelect,
  employees: RecordPayload[],
) {
  const employee = employees.find((item) => Number(item.id) === row.employeeId);
  return {
    id: row.id,
    employeeId: row.employeeId,
    employeeName: String(employee?.name ?? "Karyawan tidak ditemukan"),
    amount: row.amount,
    period: row.period,
    paymentDate: row.paymentDate,
    status: row.status,
    isDemo: row.isDemo,
  };
}

router.get("/kasir/payroll", async (_req, res): Promise<void> => {
  const [payments, employees] = await Promise.all([
    db.select().from(payrollPaymentsTable).orderBy(desc(payrollPaymentsTable.paymentDate), desc(payrollPaymentsTable.id)),
    listRecords("employee"),
  ]);
  res.json(GetPayrollPaymentsResponse.parse(payments.map((row) => payrollResponse(row, employees))));
});

router.post("/kasir/payroll", async (req, res): Promise<void> => {
  const data = parseBody(CreatePayrollPaymentBody, req.body, res);
  if (!data) return;
  const [employee] = await db
    .select()
    .from(restaurantRecordsTable)
    .where(and(eq(restaurantRecordsTable.id, data.employeeId), eq(restaurantRecordsTable.kind, "employee")));
  if (!employee) {
    res.status(404).json({ error: "Karyawan tidak ditemukan" });
    return;
  }
  try {
    const [payment] = await db.insert(payrollPaymentsTable).values({
      employeeId: data.employeeId,
      amount: data.amount,
      period: data.period,
      paymentDate: data.paymentDate,
      status: data.status,
      isDemo: isDemoData(employee.data),
    }).returning();
    res.status(201).json(CreatePayrollPaymentResponse.parse({
      ...payrollResponse(payment, [{ id: employee.id, ...employee.data }]),
    }));
  } catch (error) {
    if (isUniqueConflict(error)) {
      res.status(409).json({ error: "Pembayaran gaji untuk karyawan dan periode ini sudah tercatat." });
      return;
    }
    throw error;
  }
});

router.patch("/kasir/payroll/:id", async (req, res): Promise<void> => {
  const params = UpdatePayrollPaymentParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const data = parseBody(UpdatePayrollPaymentBody, req.body, res);
  if (!data) return;
  if (Object.keys(data).length === 0) {
    res.status(400).json({ error: "Pilih setidaknya satu informasi untuk diperbarui." });
    return;
  }
  const [existing] = await db
    .select()
    .from(payrollPaymentsTable)
    .where(eq(payrollPaymentsTable.id, params.data.id));
  if (!existing) {
    res.status(404).json({ error: "Pembayaran gaji tidak ditemukan" });
    return;
  }
  const newPeriod = data.period ?? existing.period;
  const duplicate = await db
    .select({ id: payrollPaymentsTable.id })
    .from(payrollPaymentsTable)
    .where(and(
      eq(payrollPaymentsTable.employeeId, existing.employeeId),
      eq(payrollPaymentsTable.period, newPeriod),
      ne(payrollPaymentsTable.id, existing.id),
    ))
    .limit(1);
  if (duplicate.length > 0) {
    res.status(409).json({ error: "Pembayaran gaji untuk karyawan dan periode ini sudah tercatat." });
    return;
  }
  try {
    const [updated] = await db
      .update(payrollPaymentsTable)
      .set({
        ...(data.amount !== undefined ? { amount: data.amount } : {}),
        ...(data.period !== undefined ? { period: data.period } : {}),
        ...(data.paymentDate !== undefined ? { paymentDate: data.paymentDate } : {}),
        ...(data.status !== undefined ? { status: data.status } : {}),
      })
      .where(eq(payrollPaymentsTable.id, existing.id))
      .returning();
    const employees = await listRecords("employee");
    res.json(UpdatePayrollPaymentResponse.parse(payrollResponse(updated, employees)));
  } catch (error) {
    if (isUniqueConflict(error)) {
      res.status(409).json({ error: "Pembayaran gaji untuk karyawan dan periode ini sudah tercatat." });
      return;
    }
    throw error;
  }
});

function reportingPeriod(date: string | undefined, month: string | undefined) {
  const today = new Date().toISOString().slice(0, 10);
  const selectedDate = date ?? today;
  return { date: selectedDate, month: month ?? selectedDate.slice(0, 7) };
}

router.get("/kasir/dashboard", async (req, res): Promise<void> => {
  const query = GetKasirDashboardQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: query.error.message });
    return;
  }
  const period = reportingPeriod(query.data.date, query.data.month);
  res.json(GetKasirDashboardResponse.parse(await getKasirDashboard(period.date, period.month)));
});

router.get("/kasir/reports", async (req, res): Promise<void> => {
  const query = GetReportsQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: query.error.message });
    return;
  }
  const period = reportingPeriod(query.data.date, query.data.month);
  res.json(GetReportsResponse.parse(await getKasirReports(period.date, period.month)));
});

export default router;
