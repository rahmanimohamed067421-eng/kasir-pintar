import { type ReactNode, useRef, useState } from 'react';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import {
  Activity, ArrowDownLeft, ArrowUpRight, Boxes, Calculator, CalendarDays, Check,
  ChevronDown, CircleAlert, ClipboardList, Coins, CreditCard, FileBarChart2,
  LayoutDashboard, Menu, Pencil, Plus, Receipt, Search, ShoppingBag, Users, Wallet, X,
} from 'lucide-react';
import {
  useCreateEmployee, useCreateExpense, useCreateInventoryItem,
  useCreateSale, useGetEmployees, useGetExpenses, useGetIngredients, useGetInventory,
  useCreatePayrollPayment, useGetPayrollPayments, useUpdateEmployee, useUpdatePayrollPayment,
  useGetKasirDashboard, useGetReports, useGetSales, useUpdateInventoryItem,
  useCreateMenuItem, useGetMenuItems, useUpdateMenuItem, useUpdateSaleStatus,
  getGetEmployeesQueryKey, getGetExpensesQueryKey, getGetIngredientsQueryKey,
  getGetInventoryQueryKey, getGetKasirDashboardQueryKey, getGetPayrollPaymentsQueryKey, getGetReportsQueryKey,
  getGetSalesQueryKey, getGetMenuItemsQueryKey,
} from '@workspace/api-client-react';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Link, Route, Switch, Router as WouterRouter, useLocation } from 'wouter';

const queryClient = new QueryClient();
const rupiah = (value: number | undefined | null) =>
  new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(value ?? 0);
const today = () => {
  const date = new Date();
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
};
const localMonth = () => today().slice(0, 7);
const dateLabel = (value?: string) => {
  if (!value) return '—';
  const date = /^\d{4}-\d{2}-\d{2}$/.test(value) ? new Date(`${value}T12:00:00`) : new Date(value);
  return new Intl.DateTimeFormat('id-ID', { day: 'numeric', month: 'short', year: 'numeric' }).format(date);
};
const errorText = (error: unknown, fallback: string) => {
  const e = error as { message?: string; data?: { message?: string }; status?: number };
  const message = e?.data?.message || e?.message || '';
  if (e?.status === 409 || /duplicate|already|idempot|duplikat/i.test(message)) return 'Permintaan ini sudah tercatat. Periksa riwayat sebelum mencoba lagi.';
  if (/stock|stok|insufficient/i.test(message)) return `Stok bahan tidak mencukupi. ${message}`;
  return message || fallback;
};

const navLinks = [
  { href: '/', label: 'Ringkasan', icon: LayoutDashboard },
  { href: '/food-cost', label: 'Biaya bahan', icon: Calculator },
  { href: '/orders', label: 'Pesanan', icon: ShoppingBag },
  { href: '/inventory', label: 'Stok bahan', icon: Boxes },
  { href: '/employees', label: 'Karyawan', icon: Users },
  { href: '/payroll', label: 'Penggajian', icon: Wallet },
  { href: '/expenses', label: 'Pengeluaran', icon: Receipt },
  { href: '/reports', label: 'Laporan', icon: FileBarChart2 },
];

function Shell({ children }: { children: ReactNode }) {
  const [path] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const selected = navLinks.find(item => item.href === path);
  return <div className="app-shell">
    <aside className={`sidebar ${mobileOpen ? 'sidebar-open' : ''}`}>
      <div className="brand">
        <div className="brand-mark"><span>K</span><i /></div>
        <div><strong>kasir pintar</strong><small>OPERASIONAL RESTORAN</small></div>
        <button className="icon-button mobile-close" aria-label="Tutup navigasi" onClick={() => setMobileOpen(false)}><X size={18} /></button>
      </div>
      <div className="restaurant-chip"><span className="restaurant-avatar">KP</span><span><b>Restoran Anda</b><small>Usaha utama</small></span><ChevronDown size={15} /></div>
      <div className="nav-caption">MENU UTAMA</div>
      <nav className="nav-list">
        {navLinks.map(({ href, label, icon: Icon }) => <Link key={href} href={href} onClick={() => setMobileOpen(false)} className={`nav-link ${path === href ? 'active' : ''}`} data-testid={`link-nav-${href.replace('/', '') || 'ringkasan'}`}>
          <Icon size={18} strokeWidth={1.8} /><span>{label}</span>{href === '/inventory' && <span className="nav-dot" />}
        </Link>)}
      </nav>
      <div className="sidebar-bottom">
        <div className="sidebar-note"><span className="status-pulse" /><span><b>Usaha berjalan</b><small>Semua data tersinkron</small></span></div>
        <div className="owner-card"><div className="owner-avatar">PU</div><div><b>Pemilik usaha</b><small>Akun pengelola</small></div><ChevronDown size={15} /></div>
      </div>
    </aside>
    {mobileOpen && <button aria-label="Tutup menu" className="sidebar-scrim" onClick={() => setMobileOpen(false)} />}
    <main className="main-area">
      <header className="topbar">
        <button className="icon-button menu-trigger" aria-label="Buka navigasi" onClick={() => setMobileOpen(true)}><Menu size={20} /></button>
        <div className="breadcrumb"><span>Kasir Pintar</span><span className="crumb-sep">/</span><b>{selected?.label || 'Halaman'}</b></div>
        <div className="topbar-right"><span className="today-pill"><CalendarDays size={15} />{new Intl.DateTimeFormat('id-ID', { weekday: 'long', day: 'numeric', month: 'long' }).format(new Date())}</span><div className="top-avatar">PU</div></div>
      </header>
      <div className="page-content">{children}</div>
    </main>
  </div>;
}

function Heading({ eyebrow, title, subtitle, action }: { eyebrow: string; title: string; subtitle: string; action?: ReactNode }) {
  return <div className="page-heading"><div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1><p>{subtitle}</p></div>{action && <div className="heading-action">{action}</div>}</div>;
}
function Button({ children, onClick, variant = 'primary', disabled = false, type = 'button', testId }: { children: ReactNode; onClick?: () => void; variant?: 'primary' | 'secondary' | 'quiet'; disabled?: boolean; type?: 'button' | 'submit'; testId?: string }) {
  return <button type={type} onClick={onClick} disabled={disabled} className={`button button-${variant}`} data-testid={testId}>{children}</button>;
}
function Modal({ open, onClose, title, subtitle, children }: { open: boolean; onClose: () => void; title: string; subtitle: string; children: ReactNode }) {
  if (!open) return null;
  return <div className="modal-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}>
    <section className="modal-card" role="dialog" aria-modal="true" aria-label={title}>
      <div className="modal-header"><div><h2>{title}</h2><p>{subtitle}</p></div><button className="icon-button" onClick={onClose} aria-label="Tutup"><X size={19} /></button></div>
      {children}
    </section>
  </div>;
}
function Field({ label, name, type = 'text', required = false, placeholder, defaultValue, min, step, value, onChange, children }: { label: string; name: string; type?: string; required?: boolean; placeholder?: string; defaultValue?: string | number; min?: number; step?: string; value?: string; onChange?: React.ChangeEventHandler<HTMLInputElement>; children?: ReactNode }) {
  return <label className="field"><span>{label}</span>{children || <input name={name} type={type} required={required} placeholder={placeholder} defaultValue={defaultValue} value={value} onChange={onChange} min={min} step={step} data-testid={`input-${name}`} />}</label>;
}
function LoadingState() { return <div className="loading-stack"><div className="skeleton skeleton-wide" /><div className="skeleton-grid"><div className="skeleton" /><div className="skeleton" /><div className="skeleton" /></div><div className="skeleton skeleton-table" /></div>; }
function QueryState({ loading, error, empty, children }: { loading: boolean; error: boolean; empty: boolean; children: ReactNode }) {
  if (loading) return <LoadingState />;
  if (error) return <div className="state-card error-state"><CircleAlert size={23} /><b>Data belum dapat dimuat</b><span>Periksa koneksi lalu muat ulang halaman.</span><Button variant="secondary" onClick={() => window.location.reload()}>Coba lagi</Button></div>;
  if (empty) return <div className="state-card"><div className="empty-icon"><ClipboardList size={23} /></div><b>Belum ada data</b><span>Data akan tampil di sini setelah dicatat.</span></div>;
  return <>{children}</>;
}
function StatCard({ label, value, note, icon: Icon, tone = 'red', trend }: { label: string; value: string; note: string; icon: typeof Wallet; tone?: string; trend?: string }) {
  return <div className={`stat-card tone-${tone}`}><div className="stat-top"><span>{label}</span><span className="stat-icon"><Icon size={18} /></span></div><strong className="stat-value">{value}</strong><div className="stat-note">{trend && <span className="trend"><ArrowUpRight size={13} />{trend}</span>}{note}</div></div>;
}
function Panel({ title, subtitle, action, children, className = '' }: { title: string; subtitle?: string; action?: ReactNode; children: ReactNode; className?: string }) {
  return <section className={`panel ${className}`}><div className="panel-heading"><div><h2>{title}</h2>{subtitle && <p>{subtitle}</p>}</div>{action}</div>{children}</section>;
}
function Money({ value }: { value: number }) { return <span className="money">{rupiah(value)}</span>; }

function DashboardPage() {
  const date = today();
  const month = localMonth();
  const query = useGetKasirDashboard({ date, month }, { query: { queryKey: getGetKasirDashboardQueryKey({ date, month }) } });
  const dashboard = query.data;
  const trend = dashboard?.monthlyTrend || [];
  const maxTrend = Math.max(...trend.map(item => item.revenue), 1);
  return <div className="page-enter">
    <Heading eyebrow="DASHBOARD • HARI INI" title="Selamat datang kembali" subtitle="Pantau kondisi usaha dan ambil keputusan lebih cepat." action={<span className="live-tag"><span /> DATA LANGSUNG</span>} />
    <QueryState loading={query.isLoading} error={query.isError} empty={!dashboard}>
      {dashboard && <>
        <div className="stats-grid">
          <StatCard label="Penjualan hari ini" value={rupiah(dashboard.revenue)} note="Transaksi non-demo" icon={Wallet} trend="Hari ini" />
          <StatCard label="Biaya bahan" value={rupiah(dashboard.ingredientCost)} note="Bahan yang terpakai" icon={Boxes} tone="sand" />
          <StatCard label="Laba kotor" value={rupiah(dashboard.grossProfit)} note="Penjualan dikurangi bahan" icon={Coins} tone="green" />
          <StatCard label="Laba bersih" value={rupiah(dashboard.profit)} note="Setelah biaya operasional" icon={ArrowDownLeft} tone="blue" />
        </div>
        <div className="financial-strip" data-testid="dashboard-financial-values">
          <span>Biaya operasional <b>{rupiah(dashboard.expenses)}</b></span>
          <span>Pesanan <b>{dashboard.orderCount}</b></span>
          <small>Data keuangan hanya menghitung catatan nyata; catatan demo tidak masuk total.</small>
        </div>
        <div className="dashboard-grid">
          <Panel title="Tren penjualan" subtitle="Performa omzet per bulan" className="trend-panel">
            {trend.length ? <div className="chart-wrap"><div className="chart-y"><span>{rupiah(maxTrend)}</span><span>{rupiah(maxTrend * .5)}</span><span>Rp0</span></div><div className="bar-chart">{trend.map((item, i) => <div className="bar-column" key={`${item.label}-${i}`}><div className="bar-value">{rupiah(item.revenue)}</div><div className="bar-track"><span style={{ height: `${Math.max(8, item.revenue / maxTrend * 100)}%` }} /></div><small>{item.label}</small></div>)}</div></div> : <div className="chart-empty">Belum ada tren penjualan untuk ditampilkan.</div>}
          </Panel>
          <Panel title="Perlu perhatian" subtitle="Hal yang perlu ditindaklanjuti">
            <div className="alert-feature"><div className="alert-symbol"><CircleAlert size={19} /></div><div><b>{dashboard.lowStockCount} bahan stok menipis</b><span>Periksa persediaan agar operasional tetap lancar.</span></div><Link href="/inventory" className="text-link">Lihat stok <ArrowUpRight size={14} /></Link></div>
            <div className="focus-stat"><div><span>Rasio laba bersih</span><b>{dashboard.revenue ? `${((dashboard.profit / dashboard.revenue) * 100).toFixed(1)}%` : '0%'}</b></div><div className="mini-progress"><i style={{ width: `${Math.min(100, dashboard.revenue ? Math.max(0, dashboard.profit / dashboard.revenue * 100) : 0)}%` }} /></div><small>Dari penjualan nyata hari ini</small></div>
          </Panel>
        </div>
        <Panel title="Transaksi terbaru" subtitle="Aktivitas penjualan paling baru" action={<Link href="/orders" className="text-link">Semua pesanan <ArrowUpRight size={14} /></Link>}>
           {dashboard.recentSales.length ? <div className="table-scroll"><table><thead><tr><th>No. pesanan</th><th>Rincian</th><th>Metode bayar</th><th>Status</th><th>Nilai transaksi</th></tr></thead><tbody>{dashboard.recentSales.slice(0, 5).map(sale => <tr key={sale.id}><td className="cell-strong">{sale.orderNumber}</td><td>{sale.itemsSummary} {sale.isDemo && <span className="badge badge-demo">DEMO</span>}</td><td>{sale.paymentMethod}</td><td><span className={`badge ${sale.status.toLowerCase() === 'selesai' ? 'badge-green' : 'badge-neutral'}`}>{sale.status}</span></td><td className="cell-strong">{rupiah(sale.amount)}</td></tr>)}</tbody></table></div> : <div className="inline-empty">Belum ada transaksi hari ini.</div>}
        </Panel>
        <div className="quick-strip"><div><span className="quick-mark">+</span><div><b>Catat transaksi dengan cepat</b><small>Input penjualan, pengeluaran, atau stok baru.</small></div></div><div className="quick-actions"><Link href="/orders" className="quick-link"><Plus size={15} /> Penjualan</Link><Link href="/expenses" className="quick-link"><Plus size={15} /> Pengeluaran</Link><Link href="/inventory" className="quick-link"><Plus size={15} /> Stok bahan</Link></div></div>
      </>}
    </QueryState>
  </div>;
}

function FoodCostPage() {
  const query = useGetInventory({ query: { queryKey: getGetInventoryQueryKey() } });
  const menusQuery = useGetMenuItems({ query: { queryKey: getGetMenuItemsQueryKey() } });
  const qc = useQueryClient();
  const create = useCreateMenuItem();
  const update = useUpdateMenuItem();
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState<number | null>(null);
  const ingredients = query.data || [];
  const menus = menusQuery.data || [];
  const [recipeRows, setRecipeRows] = useState<{ id: number; quantity: number }[]>([]);
  const [price, setPrice] = useState('');
  const [formError, setFormError] = useState('');
  const activeMenu = menus.find(item => item.id === editing);
  const totalCost = recipeRows.reduce((sum, row) => sum + (ingredients.find(i => i.id === row.id)?.costPerUnit || 0) * row.quantity, 0);
  const selling = Number(price) || 0;
  const gross = selling - totalCost;
  const ratio = selling ? totalCost / selling * 100 : 0;
  const startCreate = () => { setEditing(null); setRecipeRows([]); setPrice(''); setFormError(''); setModal(true); };
  const startEdit = (menu: NonNullable<typeof activeMenu>) => {
    setEditing(menu.id);
    setRecipeRows(menu.recipe.map(line => ({ id: line.inventoryId, quantity: line.quantity })));
    setPrice(String(menu.sellingPrice));
    setFormError('');
    setModal(true);
  };
  const closeModal = () => { setModal(false); setEditing(null); setFormError(''); };
  const submit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const name = String(data.get('name')).trim();
    if (!recipeRows.length || recipeRows.some(row => row.quantity <= 0)) { setFormError('Tambahkan minimal satu bahan dengan takaran lebih dari nol.'); return; }
    if (!name || Number(data.get('sellingPrice')) < 1) { setFormError('Nama menu dan harga jual wajib diisi dengan benar.'); return; }
    const payload = { name, sellingPrice: Number(data.get('sellingPrice')), recipe: recipeRows.map(row => ({ inventoryId: row.id, quantity: row.quantity })) };
    const success = () => {
      qc.invalidateQueries({ queryKey: getGetMenuItemsQueryKey() });
      qc.invalidateQueries({ queryKey: getGetIngredientsQueryKey() });
      closeModal();
    };
    if (editing !== null) update.mutate({ id: editing, data: payload }, { onSuccess: success, onError: error => setFormError(errorText(error, 'Menu belum tersimpan. Coba lagi.')) });
    else create.mutate({ data: payload }, { onSuccess: success, onError: error => setFormError(errorText(error, 'Menu belum tersimpan. Coba lagi.')) });
  };
  const saving = create.isPending || update.isPending;
  return <div className="page-enter">
    <Heading eyebrow="MENU • RESEP" title="Biaya bahan per menu" subtitle="Simpan resep per porsi dan lihat laba kotor dari harga jual." action={<Button onClick={startCreate} testId="button-create-menu"><Plus size={16} /> Menu baru</Button>} />
    <QueryState loading={query.isLoading || menusQuery.isLoading} error={query.isError || menusQuery.isError} empty={false}>
      <div className="food-grid">
        <Panel title="Komposisi resep" subtitle="Tambahkan bahan dan takaran untuk satu porsi" className="recipe-panel">
          <div className="ingredient-head"><span>BAHAN</span><span>TAKARAN</span><span>BIAYA</span><span /></div>
          {!ingredients.length ? <div className="inline-empty">Belum ada stok bahan. Tambahkan stok terlebih dahulu untuk menyusun resep.</div> : recipeRows.length === 0 ? <div className="recipe-placeholder"><Calculator size={23} /><b>Mulai dari bahan resep</b><span>Pilih bahan di bawah untuk menghitung total biaya.</span></div> : recipeRows.map((row, index) => {
            const item = ingredients.find(i => i.id === row.id);
            return <div className="ingredient-row" key={`${row.id}-${index}`}><div className="ingredient-name"><span className="ingredient-dot">{item?.name.slice(0, 1).toUpperCase()}</span><span><b>{item?.name}</b><small>{rupiah(item?.costPerUnit || 0)} / {item?.unit}{item?.isDemo && ' · DEMO'}</small></span></div><label className="quantity-input"><input type="number" min="0" step="0.01" value={row.quantity} onChange={e => setRecipeRows(old => old.map((r, i) => i === index ? { ...r, quantity: Number(e.target.value) } : r))} aria-label={`Takaran ${item?.name}`} data-testid={`input-recipe-quantity-${row.id}`} /><span>{item?.unit}</span></label><b className="row-cost">{rupiah((item?.costPerUnit || 0) * row.quantity)}</b><button type="button" className="icon-button remove-row" aria-label="Hapus bahan" data-testid={`button-remove-recipe-${row.id}`} onClick={() => setRecipeRows(old => old.filter((_, i) => i !== index))}><X size={16} /></button></div>;
          })}
          <div className="add-ingredient-line"><select aria-label="Pilih bahan untuk ditambahkan" data-testid="select-recipe-ingredient" defaultValue="" onChange={e => { if (e.target.value) { const id = Number(e.target.value); setRecipeRows(old => [...old, { id, quantity: 1 }]); e.target.value = ''; } }}><option value="" disabled>+ Tambahkan bahan dari stok</option>{ingredients.map(item => <option value={item.id} key={item.id}>{item.name}{item.isDemo ? ' · DEMO' : ''} · {rupiah(item.costPerUnit)} / {item.unit}</option>)}</select></div>
          <div className="cost-total"><span>Total biaya bahan</span><strong>{rupiah(totalCost)}</strong></div>
        </Panel>
        <div className="calculator-side">
          <Panel title="Harga jual" subtitle="Masukkan harga jual per porsi">
            <label className="field price-field"><span>HARGA JUAL</span><div className="currency-input"><span>Rp</span><input type="number" min="0" value={price} onChange={e => setPrice(e.target.value)} placeholder="0" data-testid="input-harga-jual" /></div></label>
            <div className="calculation-line"><span>Biaya bahan</span><b>{rupiah(totalCost)}</b></div><div className="calculation-line"><span>Laba kotor</span><b className={gross < 0 ? 'negative' : 'positive'}>{rupiah(gross)}</b></div>
          </Panel>
          <div className="food-result"><div className="result-heading"><div><span>RASIO BIAYA BAHAN</span><b>{ratio.toFixed(1)}%</b></div><div className="result-ring" style={{ '--ratio': `${Math.min(ratio, 100)}%` } as React.CSSProperties}><span>{Math.round(ratio)}<small>%</small></span></div></div><div className="result-bar"><i style={{ width: `${Math.min(ratio, 100)}%` }} /></div><p>{ratio > 35 ? 'Biaya bahan cukup tinggi. Pertimbangkan penyesuaian porsi atau harga jual.' : ratio > 0 ? 'Biaya bahan terukur. Jaga konsistensi resep dan porsi.' : 'Isi bahan dan harga jual untuk melihat persentasenya.'}</p><div className="benchmark"><span>Patokan sehat</span><b>25–35%</b></div></div>
        </div>
      </div>
      <Panel title="Menu dan laba kotor" subtitle={`${menus.length} menu tersimpan`}>
        {menus.length ? <div className="table-scroll"><table><thead><tr><th>Menu</th><th>Biaya bahan / porsi</th><th>Harga jual</th><th>Laba kotor</th><th>Rasio bahan</th><th>Aksi</th></tr></thead><tbody>{menus.map(item => <tr key={item.id} data-testid={`row-menu-${item.id}`}><td className="cell-strong">{item.name}{item.usesDemoInventory && <span className="badge badge-demo">DEMO</span>}</td><td>{rupiah(item.ingredientCost)}</td><td>{rupiah(item.sellingPrice)}</td><td className={item.grossProfit < 0 ? 'negative' : 'positive'}>{rupiah(item.grossProfit)}</td><td>{item.foodCostPercent.toFixed(1)}%</td><td><button className="table-action" data-testid={`button-edit-menu-${item.id}`} onClick={() => startEdit(item)}><Pencil size={13} /> Ubah resep</button></td></tr>)}</tbody></table></div> : <div className="inline-empty">Belum ada menu tersimpan. Buat menu pertama dengan resep dan harga jual.</div>}
      </Panel>
    </QueryState>
    <Modal open={modal} onClose={closeModal} title={editing ? 'Ubah menu dan resep' : 'Buat menu dan resep'} subtitle="Takaran bahan dihitung untuk satu porsi.">
      <form key={editing ?? 'new'} className="modal-form" onSubmit={submit}>
        <Field label="Nama menu" name="name" required placeholder="Contoh: Nasi goreng kampung" defaultValue={activeMenu?.name} />
        <Field label="Harga jual per porsi" name="sellingPrice" type="number" min={1} required placeholder="0" defaultValue={activeMenu?.sellingPrice} />
        <div className="recipe-editor">
          <b>Bahan untuk satu porsi</b>
          {recipeRows.map((row, index) => {
            const ingredient = ingredients.find(item => item.id === row.id);
            return <div className="recipe-edit-row" key={`${row.id}-${index}`}>
              <span>{ingredient?.name || 'Bahan tidak ditemukan'} <small>{ingredient?.unit}</small></span>
              <input aria-label={`Takaran resep ${ingredient?.name || ''}`} type="number" min="0.01" step="0.01" value={row.quantity} onChange={e => setRecipeRows(old => old.map((entry, i) => i === index ? { ...entry, quantity: Number(e.target.value) } : entry))} data-testid={`input-menu-recipe-${index}`} />
              <button type="button" className="icon-button" aria-label="Hapus bahan resep" onClick={() => setRecipeRows(old => old.filter((_, i) => i !== index))}><X size={15} /></button>
            </div>;
          })}
          <select aria-label="Tambah bahan ke resep" data-testid="select-menu-recipe-ingredient" defaultValue="" onChange={e => { if (e.target.value) { const id = Number(e.target.value); setRecipeRows(old => [...old, { id, quantity: 1 }]); e.target.value = ''; } }}>
            <option value="" disabled>+ Tambahkan bahan stok</option>{ingredients.map(item => <option key={item.id} value={item.id}>{item.name}{item.isDemo ? ' · DEMO' : ''} · {item.unit}</option>)}
          </select>
          <div className="recipe-cost-preview">Biaya bahan per porsi <b>{rupiah(totalCost)}</b> <span>Laba kotor <b className={selling - totalCost < 0 ? 'negative' : 'positive'}>{rupiah(selling - totalCost)}</b></span></div>
        </div>
        {formError && <div className="duplicate-notice" role="alert"><CircleAlert size={16} /><span>{formError}</span></div>}
        <div className="modal-actions"><Button variant="secondary" onClick={closeModal}>Batal</Button><Button type="submit" disabled={saving || !ingredients.length}>{saving ? 'Menyimpan…' : editing ? 'Simpan perubahan' : 'Simpan menu'}</Button></div>
      </form>
    </Modal>
  </div>;
}

function OrdersPage() {
  const q = useGetSales({ query: { queryKey: getGetSalesQueryKey() } });
  const menuQuery = useGetMenuItems({ query: { queryKey: getGetMenuItemsQueryKey() } });
  const qc = useQueryClient();
  const create = useCreateSale();
  const updateStatus = useUpdateSaleStatus();
  const [modal, setModal] = useState(false);
  const [lines, setLines] = useState<{ menuItemId: number; quantity: number }[]>([]);
  const [saleDate, setSaleDate] = useState(today());
  const [formError, setFormError] = useState('');
  const [actionError, setActionError] = useState('');
  const pendingKey = useRef<string | null>(null);
  const sales = q.data || [];
  const menus = menuQuery.data || [];
  const totalSales = sales.filter(s => !s.isDemo && !['cancelled', 'refunded'].includes(s.status.toLowerCase())).reduce((sum, s) => sum + s.amount, 0);
  const beginSale = () => {
    pendingKey.current = `kp-${globalThis.crypto?.randomUUID?.() || `${Date.now()}-${Math.random().toString(36).slice(2)}`}`;
    setLines([]); setSaleDate(today()); setFormError(''); setModal(true);
  };
  const closeSale = () => { setModal(false); setFormError(''); pendingKey.current = null; };
  const refreshSaleData = () => {
    qc.invalidateQueries({ queryKey: getGetSalesQueryKey() });
    qc.invalidateQueries({ queryKey: getGetKasirDashboardQueryKey() });
    qc.invalidateQueries({ queryKey: getGetReportsQueryKey() });
    qc.invalidateQueries({ queryKey: getGetInventoryQueryKey() });
    qc.invalidateQueries({ queryKey: getGetIngredientsQueryKey() });
    qc.invalidateQueries({ queryKey: getGetMenuItemsQueryKey() });
  };
  const submit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (create.isPending) return;
    const d = new FormData(e.currentTarget);
    if (!lines.length || lines.some(line => line.quantity < 1)) { setFormError('Pilih minimal satu menu dan jumlah porsi yang valid.'); return; }
    if (!pendingKey.current) pendingKey.current = `kp-${globalThis.crypto?.randomUUID?.() || `${Date.now()}-${Math.random().toString(36).slice(2)}`}`;
    setFormError('');
    create.mutate({ data: { lines, paymentMethod: String(d.get('paymentMethod')), saleDate, idempotencyKey: pendingKey.current } }, {
      onSuccess: () => { refreshSaleData(); closeSale(); setActionError('Penjualan berhasil dicatat. Stok bahan diperbarui oleh server.'); },
      onError: error => setFormError(errorText(error, 'Transaksi belum tersimpan. Periksa stok dan coba lagi.')),
    });
  };
  const changeStatus = (saleId: number, status: 'cancelled' | 'refunded') => {
    if (!window.confirm(status === 'cancelled' ? 'Batalkan pesanan ini? Stok bahan akan dipulihkan oleh sistem.' : 'Proses pengembalian dana? Stok bahan akan dipulihkan oleh sistem.')) return;
    setActionError('');
    updateStatus.mutate({ id: saleId, data: { status } }, {
      onSuccess: () => { refreshSaleData(); setActionError('Status diperbarui. Stok bahan dipulihkan sesuai proses server.'); },
      onError: error => setActionError(errorText(error, 'Status pesanan belum berubah. Coba lagi.')),
    });
  };
  const selectedLines = lines.map(line => ({ line, menu: menus.find(menu => menu.id === line.menuItemId) })).filter(entry => entry.menu);
  const orderTotal = selectedLines.reduce((sum, entry) => sum + (entry.menu?.sellingPrice || 0) * entry.line.quantity, 0);
  return <div className="page-enter"><Heading eyebrow="PENJUALAN • TRANSAKSI" title="Pesanan & penjualan" subtitle="Catat transaksi dari menu tersimpan; stok diperiksa oleh server." action={<Button onClick={beginSale} testId="button-create-sale"><Plus size={16} /> Catat penjualan</Button>} />
    <div className="inline-summary"><div><ShoppingBag size={17} /><span>Transaksi tersimpan</span><b>{sales.length}</b></div><div><CreditCard size={17} /><span>Penjualan nyata aktif</span><b data-testid="sales-total">{rupiah(totalSales)}</b></div><div><span className="badge badge-demo">DEMO dikecualikan</span></div></div>
    {actionError && <div className="inline-notice" role="status" data-testid="sale-status-feedback">{actionError}</div>}
    <Panel title="Riwayat transaksi" subtitle="Catatan demo ditandai dan tidak masuk total keuangan"><QueryState loading={q.isLoading || menuQuery.isLoading} error={q.isError || menuQuery.isError} empty={!q.isLoading && !q.isError && !sales.length}>{sales.length ? <div className="table-scroll"><table><thead><tr><th>No. pesanan</th><th>Menu dipesan</th><th>Tanggal</th><th>Pembayaran</th><th>Status</th><th>Jumlah</th><th>Aksi</th></tr></thead><tbody>{sales.map(s => <tr key={s.id} data-testid={`row-sale-${s.id}`}><td className="cell-strong">{s.orderNumber}{s.isDemo && <span className="badge badge-demo">DEMO</span>}</td><td>{s.itemsSummary}</td><td>{dateLabel(s.saleDate || s.createdAt)}</td><td>{s.paymentMethod}</td><td><span className={`badge ${['selesai', 'completed'].includes(s.status.toLowerCase()) ? 'badge-green' : 'badge-neutral'}`}>{s.status}</span></td><td className="cell-strong">{rupiah(s.amount)}</td><td>{!s.isDemo && !['cancelled', 'refunded'].includes(s.status.toLowerCase()) ? <div className="sale-actions"><button className="table-action" data-testid={`button-cancel-sale-${s.id}`} disabled={updateStatus.isPending} onClick={() => changeStatus(s.id, 'cancelled')}>Batalkan</button><button className="table-action refund-action" data-testid={`button-refund-sale-${s.id}`} disabled={updateStatus.isPending} onClick={() => changeStatus(s.id, 'refunded')}>Refund</button></div> : '—'}</td></tr>)}</tbody></table></div> : null}</QueryState></Panel>
    <Modal open={modal} onClose={closeSale} title="Catat penjualan" subtitle="Pilih menu tersimpan. Server akan memvalidasi dan mengurangi stok bahan.">
      <form className="modal-form" onSubmit={submit}>
        {!menus.length ? <div className="inline-empty">Belum ada menu. Buat menu dan resep di Biaya bahan sebelum mencatat penjualan.</div> : <div className="sale-line-list">
          {lines.map((line, index) => {
            const menu = menus.find(item => item.id === line.menuItemId);
            return <div className="sale-line" key={`${line.menuItemId}-${index}`}><label className="field"><span>Menu</span><select aria-label="Menu pesanan" value={line.menuItemId} onChange={e => setLines(old => old.map((entry, i) => i === index ? { ...entry, menuItemId: Number(e.target.value) } : entry))} data-testid={`select-sale-menu-${index}`}>{menus.map(item => <option key={item.id} value={item.id}>{item.name}{item.usesDemoInventory ? ' · DEMO BAHAN' : ''} · {rupiah(item.sellingPrice)}</option>)}</select></label><label className="field"><span>Porsi</span><input type="number" min="1" step="1" value={line.quantity} onChange={e => setLines(old => old.map((entry, i) => i === index ? { ...entry, quantity: Number(e.target.value) } : entry))} data-testid={`input-sale-quantity-${index}`} /></label><button type="button" className="icon-button" aria-label="Hapus menu" data-testid={`button-remove-sale-line-${index}`} onClick={() => setLines(old => old.filter((_, i) => i !== index))}><X size={16} /></button><small>{menu?.usesDemoInventory ? 'Resep memakai stok demo; transaksi akan diberi label demo.' : 'Stok nyata akan diperiksa saat disimpan.'}</small></div>;
          })}
          <button type="button" className="table-action add-sale-line" data-testid="button-add-sale-line" onClick={() => setLines(old => [...old, { menuItemId: menus[0].id, quantity: 1 }])}><Plus size={14} /> Tambah menu</button>
        </div>}
        {!lines.length && menus.length > 0 && <button type="button" className="button button-secondary" data-testid="button-add-first-sale-line" onClick={() => setLines([{ menuItemId: menus[0].id, quantity: 1 }])}><Plus size={14} /> Pilih menu</button>}
        <div className="form-row"><Field label="Tanggal penjualan" name="saleDate" type="date" required value={saleDate} onChange={e => setSaleDate(e.target.value)} /><Field label="Metode pembayaran" name="paymentMethod" required><select name="paymentMethod" data-testid="select-sale-payment"><option value="Tunai">Tunai</option><option value="QRIS">QRIS</option><option value="Transfer">Transfer</option><option value="Kartu">Kartu</option></select></Field></div>
        <div className="cost-total sale-total"><span>Total pesanan</span><strong data-testid="sale-form-total">{rupiah(orderTotal)}</strong></div>
        {formError && <div className="duplicate-notice" role="alert" data-testid="sale-form-error"><CircleAlert size={16} /><span>{formError}</span></div>}
        <div className="modal-actions"><Button variant="secondary" onClick={closeSale}>Batal</Button><Button type="submit" disabled={create.isPending || !menus.length || !lines.length} testId="button-submit-sale">{create.isPending ? 'Menyimpan…' : 'Simpan transaksi'}</Button></div>
      </form>
    </Modal>
  </div>;
}

function InventoryPage() {
  const q = useGetInventory({ query: { queryKey: getGetInventoryQueryKey() } });
  const qc = useQueryClient(); const create = useCreateInventoryItem(); const update = useUpdateInventoryItem(); const [modal, setModal] = useState(false); const [adjust, setAdjust] = useState<number | null>(null); const [amount, setAmount] = useState(''); const [unitCost, setUnitCost] = useState('');
  const items = q.data || []; const low = items.filter(i => i.quantity <= i.minimum);
  const submit = (e: React.FormEvent<HTMLFormElement>) => { e.preventDefault(); const d = new FormData(e.currentTarget); create.mutate({ data: { name: String(d.get('name')), category: String(d.get('category')), unit: String(d.get('unit')), quantity: Number(d.get('quantity')), minimum: Number(d.get('minimum')), costPerUnit: Number(d.get('costPerUnit')) } }, { onSuccess: () => { qc.invalidateQueries({ queryKey: getGetInventoryQueryKey() }); qc.invalidateQueries({ queryKey: getGetIngredientsQueryKey() }); qc.invalidateQueries({ queryKey: getGetMenuItemsQueryKey() }); qc.invalidateQueries({ queryKey: getGetKasirDashboardQueryKey() }); qc.invalidateQueries({ queryKey: getGetReportsQueryKey() }); setModal(false); } }); };
  const refreshInventory = () => {
    qc.invalidateQueries({ queryKey: getGetInventoryQueryKey() });
    qc.invalidateQueries({ queryKey: getGetIngredientsQueryKey() });
    qc.invalidateQueries({ queryKey: getGetMenuItemsQueryKey() });
    qc.invalidateQueries({ queryKey: getGetKasirDashboardQueryKey() });
    qc.invalidateQueries({ queryKey: getGetReportsQueryKey() });
  };
  const saveAdjust = () => { const item = items.find(i => i.id === adjust); if (!item) return; update.mutate({ id: item.id, data: { quantity: Number(amount), costPerUnit: Number(unitCost) } }, { onSuccess: () => { refreshInventory(); setAdjust(null); }, onError: error => window.alert(errorText(error, 'Perubahan stok belum tersimpan.')) }); };
  const promoteDemo = (id: number, name: string) => {
    if (!window.confirm(`Jadikan stok "${name}" sebagai stok nyata terverifikasi? Pastikan jumlah dan biaya sudah diperiksa.`)) return;
    update.mutate({ id, data: { isDemo: false } }, { onSuccess: refreshInventory, onError: error => window.alert(errorText(error, 'Stok demo belum dapat dipromosikan.')) });
  };
  return <div className="page-enter"><Heading eyebrow="PERSEDIAAN • BAHAN" title="Stok bahan" subtitle="Pantau persediaan, atur stok minimum, dan hindari kehabisan bahan." action={<Button onClick={() => setModal(true)}><Plus size={16} /> Tambah stok</Button>} />
    <div className="stats-grid compact-stats"><StatCard label="Jenis bahan" value={String(items.length)} note="Total item tersimpan" icon={Boxes} tone="sand" /><StatCard label="Stok menipis" value={String(low.length)} note="Perlu segera diperiksa" icon={CircleAlert} tone={low.length ? 'red' : 'green'} /><StatCard label="Nilai stok nyata" value={rupiah(items.filter(i => !i.isDemo).reduce((sum, i) => sum + i.quantity * i.costPerUnit, 0))} note="Demo tidak dihitung" icon={Coins} tone="blue" /></div>
    {low.length > 0 && <div className="low-stock-banner"><span className="alert-symbol"><CircleAlert size={18} /></span><div><b>{low.length} bahan membutuhkan perhatian</b><span>{low.slice(0, 3).map(i => i.name).join(', ')}{low.length > 3 ? ` dan ${low.length - 3} lainnya` : ''} berada di bawah batas minimum.</span></div></div>}
    <Panel title="Daftar persediaan" subtitle="Jumlah tersedia dibandingkan dengan batas minimum" action={<div className="search-box"><Search size={15} /><input aria-label="Cari bahan" placeholder="Cari bahan…" onChange={e => document.querySelectorAll<HTMLTableRowElement>('[data-item-row]').forEach(row => { row.hidden = !row.dataset.itemRow?.toLowerCase().includes(e.target.value.toLowerCase()); })} /></div>}>
      <QueryState loading={q.isLoading} error={q.isError} empty={!q.isLoading && !q.isError && items.length === 0}>{items.length ? <div className="table-scroll"><table><thead><tr><th>Nama bahan</th><th>Kategori</th><th>Jumlah tersedia</th><th>Batas minimum</th><th>Biaya / satuan</th><th>Status</th><th>Aksi</th></tr></thead><tbody>{items.map(i => <tr key={i.id} data-item-row={i.name} data-testid={`row-inventory-${i.id}`}><td className="cell-strong">{i.name} {i.isDemo && <span className="badge badge-demo">DEMO</span>}</td><td>{i.category}</td><td className="cell-strong">{i.quantity} {i.unit}</td><td>{i.minimum} {i.unit}</td><td>{rupiah(i.costPerUnit)}</td><td><span className={`badge ${i.quantity <= i.minimum ? 'badge-red' : 'badge-green'}`}>{i.quantity <= i.minimum ? 'Stok menipis' : 'Aman'}</span></td><td><div className="inventory-actions"><button className="table-action" data-testid={`button-adjust-stock-${i.id}`} onClick={() => { setAdjust(i.id); setAmount(String(i.quantity)); setUnitCost(String(i.costPerUnit)); }}>Atur stok <ArrowUpRight size={13} /></button>{i.isDemo && <button className="table-action promote-action" data-testid={`button-promote-stock-${i.id}`} disabled={update.isPending} onClick={() => promoteDemo(i.id, i.name)}>Verifikasi jadi nyata</button>}</div></td></tr>)}</tbody></table></div> : null}</QueryState>
    </Panel>
    <Modal open={modal} onClose={() => setModal(false)} title="Tambah item stok" subtitle="Masukkan bahan baru beserta jumlah dan batas minimumnya."><form className="modal-form" onSubmit={submit}><Field label="Nama bahan" name="name" required placeholder="Contoh: Minyak goreng" /><div className="form-row"><Field label="Kategori" name="category" required placeholder="Bahan pokok" /><Field label="Satuan" name="unit" required placeholder="liter, kg, pcs" /></div><div className="form-row"><Field label="Jumlah tersedia" name="quantity" type="number" min={0} required placeholder="0" /><Field label="Batas minimum" name="minimum" type="number" min={0} required placeholder="0" /></div><Field label="Biaya per satuan" name="costPerUnit" type="number" min={0} required placeholder="0" /><div className="modal-actions"><Button variant="secondary" onClick={() => setModal(false)}>Batal</Button><Button type="submit" disabled={create.isPending}>{create.isPending ? 'Menyimpan…' : 'Simpan item'}</Button></div></form></Modal>
    <Modal open={adjust !== null} onClose={() => setAdjust(null)} title="Atur persediaan" subtitle={`Perbarui jumlah dan biaya ${items.find(i => i.id === adjust)?.name || ''}.`}><div className="modal-form"><Field label={`Jumlah tersedia (${items.find(i => i.id === adjust)?.unit || 'satuan'})`} name="stock" type="number" min={0} required value={amount} onChange={(e: React.ChangeEvent<HTMLInputElement>) => setAmount(e.target.value)} /><Field label="Biaya per satuan" name="stock-cost" type="number" min={0} required value={unitCost} onChange={(e: React.ChangeEvent<HTMLInputElement>) => setUnitCost(e.target.value)} /><div className="modal-actions"><Button variant="secondary" onClick={() => setAdjust(null)}>Batal</Button><Button onClick={saveAdjust} disabled={update.isPending}>{update.isPending ? 'Menyimpan…' : 'Perbarui stok'}</Button></div></div></Modal>
  </div>;
}

function EmployeesPage() {
  const q = useGetEmployees({ query: { queryKey: getGetEmployeesQueryKey() } });
  const qc = useQueryClient();
  const create = useCreateEmployee();
  const update = useUpdateEmployee();
  const [editing, setEditing] = useState<(typeof q.data extends (infer E)[] | undefined ? E : never) | null>(null);
  const [modal, setModal] = useState(false);
  const closeModal = () => { setModal(false); setEditing(null); };
  const submit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const d = new FormData(e.currentTarget);
    const data = { name: String(d.get('name')).trim(), role: String(d.get('role')).trim(), salary: Number(d.get('salary')), phone: String(d.get('phone') || '').trim(), email: String(d.get('email') || '').trim() };
    const onSuccess = () => { qc.invalidateQueries({ queryKey: getGetEmployeesQueryKey() }); closeModal(); };
    if (editing) update.mutate({ id: editing.id, data }, { onSuccess });
    else create.mutate({ data }, { onSuccess });
  };
  const people = q.data || [];
  const saving = create.isPending || update.isPending;
  return <div className="page-enter"><Heading eyebrow="TIM • PENGELOLAAN" title="Karyawan" subtitle="Simpan kontak tim, jabatan, dan gaji bulanan dalam satu tempat." action={<Button onClick={() => { setEditing(null); setModal(true); }}><Plus size={16} /> Tambah karyawan</Button>} />
    <div className="inline-summary"><div><Users size={17} /><span>Total karyawan</span><b>{people.length}</b></div><div><Wallet size={17} /><span>Total gaji bulanan</span><b>{rupiah(people.reduce((s, person) => s + person.salary, 0))}</b></div></div>
    <Panel title="Tim restoran" subtitle="Informasi karyawan, kontak, dan gaji per bulan"><QueryState loading={q.isLoading} error={q.isError} empty={!q.isLoading && !q.isError && people.length === 0}>{people.length ? <div className="table-scroll"><table><thead><tr><th>Nama karyawan</th><th>Jabatan</th><th>Kontak</th><th>Status</th><th>Gaji per bulan</th><th>Aksi</th></tr></thead><tbody>{people.map(person => <tr key={person.id} data-testid={`row-employee-${person.id}`}><td><div className="person-cell"><span className="person-avatar">{person.name.split(' ').map(n => n[0]).slice(0, 2).join('').toUpperCase()}</span><b>{person.name}</b></div></td><td>{person.role}</td><td><span className="employee-contact">{person.phone || '—'}<small>{person.email || 'Email belum diisi'}</small></span></td><td><span className={`badge ${person.status.toLowerCase() === 'aktif' ? 'badge-green' : 'badge-neutral'}`}>{person.status}</span></td><td className="cell-strong">{rupiah(person.salary)}</td><td><button className="table-action" data-testid={`button-edit-employee-${person.id}`} onClick={() => { setEditing(person); setModal(true); }}><Pencil size={13} /> Ubah data</button></td></tr>)}</tbody></table></div> : null}</QueryState></Panel>
    <Modal open={modal} onClose={closeModal} title={editing ? 'Ubah data karyawan' : 'Tambah karyawan'} subtitle={editing ? 'Perbarui informasi anggota tim.' : 'Catat anggota tim dan gaji bulanan.'}><form key={editing?.id ?? 'new'} className="modal-form" onSubmit={submit}><Field label="Nama lengkap" name="name" required placeholder="Nama karyawan" defaultValue={editing?.name} /><Field label="Jabatan" name="role" required placeholder="Contoh: Koki" defaultValue={editing?.role} /><Field label="Gaji per bulan" name="salary" type="number" min={0} required placeholder="0" defaultValue={editing?.salary} /><div className="form-row"><Field label="Nomor telepon" name="phone" type="tel" placeholder="08xxxxxxxxxx" defaultValue={editing?.phone || ''} /><Field label="Email" name="email" type="email" placeholder="nama@email.com" defaultValue={editing?.email || ''} /></div><div className="modal-actions"><Button variant="secondary" onClick={closeModal}>Batal</Button><Button type="submit" disabled={saving}>{saving ? 'Menyimpan…' : editing ? 'Simpan perubahan' : 'Simpan karyawan'}</Button></div></form></Modal>
  </div>;
}

function PayrollPage() {
  const employeesQuery = useGetEmployees({ query: { queryKey: getGetEmployeesQueryKey() } });
  const paymentsQuery = useGetPayrollPayments({ query: { queryKey: getGetPayrollPaymentsQueryKey() } });
  const qc = useQueryClient();
  const create = useCreatePayrollPayment();
  const update = useUpdatePayrollPayment();
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState<(typeof paymentsQuery.data extends (infer P)[] | undefined ? P : never) | null>(null);
  const [employeeFilter, setEmployeeFilter] = useState('all');
  const [formEmployee, setFormEmployee] = useState('');
  const [formPeriod, setFormPeriod] = useState(today().slice(0, 7));
  const [errorMessage, setErrorMessage] = useState('');
  const employees = employeesQuery.data || [];
  const payments = paymentsQuery.data || [];
  const duplicate = !!formEmployee && payments.some(item => item.employeeId === Number(formEmployee) && item.period === formPeriod && item.id !== editing?.id);
  const filtered = employeeFilter === 'all' ? payments : payments.filter(item => item.employeeId === Number(employeeFilter));
  const closeModal = () => { setModal(false); setEditing(null); setErrorMessage(''); setFormEmployee(''); setFormPeriod(today().slice(0, 7)); };
  const conflictMessage = (error: unknown) => {
    const candidate = error as { status?: number; message?: string; data?: { message?: string } };
    const text = `${candidate?.message || ''} ${candidate?.data?.message || ''}`.toLowerCase();
    return candidate?.status === 409 || text.includes('conflict') || text.includes('already') || text.includes('duplicate')
      ? 'Pembayaran untuk karyawan dan periode ini sudah tercatat. Periksa riwayat sebelum mencoba lagi.'
      : candidate?.data?.message || candidate?.message || 'Pembayaran belum tersimpan. Periksa data dan coba lagi.';
  };
  const submit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const d = new FormData(e.currentTarget);
    const amount = Number(d.get('amount'));
    const period = String(d.get('period'));
    const paymentDate = String(d.get('paymentDate'));
    if (payments.some(item => item.employeeId === Number(formEmployee) && item.period === period && item.id !== editing?.id)) {
      setErrorMessage('Pembayaran untuk karyawan dan periode ini sudah ada di riwayat.');
      return;
    }
    setErrorMessage('');
    const success = () => {
      qc.invalidateQueries({ queryKey: getGetPayrollPaymentsQueryKey() });
      qc.invalidateQueries({ queryKey: getGetEmployeesQueryKey() });
      closeModal();
    };
    if (editing) {
      update.mutate({ id: editing.id, data: { amount, period, paymentDate, status: String(d.get('status')) as 'pending' | 'paid' } }, { onSuccess: success, onError: error => setErrorMessage(conflictMessage(error)) });
    } else {
      create.mutate({ data: { employeeId: Number(formEmployee), amount, period, paymentDate, status: String(d.get('status')) as 'pending' | 'paid' } }, { onSuccess: success, onError: error => setErrorMessage(conflictMessage(error)) });
    }
  };
  const startCreate = () => {
    setEditing(null); setErrorMessage('');
    setFormEmployee(employees[0] ? String(employees[0].id) : '');
    setFormPeriod(today().slice(0, 7)); setModal(true);
  };
  const startEdit = (payment: NonNullable<typeof editing>) => {
    setEditing(payment); setFormEmployee(String(payment.employeeId)); setFormPeriod(payment.period); setErrorMessage(''); setModal(true);
  };
  const saving = create.isPending || update.isPending;
  const loadError = employeesQuery.isError || paymentsQuery.isError;
  return <div className="page-enter">
    <Heading eyebrow="TIM • KEUANGAN" title="Penggajian" subtitle="Catat pembayaran gaji dan cek riwayat setiap anggota tim." action={<Button onClick={startCreate} disabled={!employees.length}><Plus size={16} /> Catat pembayaran</Button>} />
    <div className="inline-summary"><div><Wallet size={17} /><span>Total pembayaran tercatat</span><b>{rupiah(payments.reduce((sum, item) => sum + item.amount, 0))}</b></div><div><ClipboardList size={17} /><span>Riwayat pembayaran</span><b>{payments.length} catatan</b></div></div>
    <Panel title="Riwayat pembayaran" subtitle={employeeFilter === 'all' ? 'Seluruh pembayaran gaji tim' : `Riwayat ${employees.find(person => person.id === Number(employeeFilter))?.name || 'karyawan'}`} action={<label className="payroll-filter"><span>Filter karyawan</span><select aria-label="Filter riwayat berdasarkan karyawan" data-testid="select-payroll-employee" value={employeeFilter} onChange={e => setEmployeeFilter(e.target.value)}><option value="all">Semua karyawan</option>{employees.map(person => <option key={person.id} value={person.id}>{person.name}</option>)}</select></label>}>
      {loadError ? <QueryState loading={false} error empty={false}>{null}</QueryState> : paymentsQuery.isLoading || employeesQuery.isLoading ? <LoadingState /> : filtered.length ? <div className="table-scroll"><table><thead><tr><th>Karyawan</th><th>Periode gaji</th><th>Tanggal bayar</th><th>Jumlah</th><th>Status</th><th>Aksi</th></tr></thead><tbody>{filtered.map(payment => <tr key={payment.id} data-testid={`row-payroll-${payment.id}`}><td className="cell-strong">{payment.employeeName}</td><td>{new Intl.DateTimeFormat('id-ID', { month: 'long', year: 'numeric' }).format(new Date(`${payment.period}-01T00:00:00`))}</td><td>{dateLabel(payment.paymentDate)}</td><td className="cell-strong">{rupiah(payment.amount)}</td><td><span className={`badge ${payment.status === 'paid' ? 'badge-green' : 'badge-neutral'}`}>{payment.status === 'paid' ? 'Lunas' : 'Menunggu'}</span></td><td><button className="table-action" data-testid={`button-edit-payment-${payment.id}`} onClick={() => startEdit(payment)}><Pencil size={13} /> Ubah</button></td></tr>)}</tbody></table></div> : <div className="payroll-empty"><div className="empty-icon"><Wallet size={22} /></div><b>{employeeFilter === 'all' ? 'Belum ada pembayaran gaji' : 'Belum ada riwayat pembayaran'}</b><span>{employeeFilter === 'all' ? 'Pembayaran pertama akan muncul di sini, lengkap dengan periode dan statusnya.' : 'Belum ada pembayaran yang tercatat untuk karyawan ini.'}</span>{employeeFilter === 'all' && employees.length > 0 && <Button onClick={startCreate}><Plus size={15} /> Catat pembayaran</Button>}</div>}
    </Panel>
    <Modal open={modal} onClose={closeModal} title={editing ? 'Ubah pembayaran gaji' : 'Catat pembayaran gaji'} subtitle={editing ? `Perbarui catatan ${editing.employeeName}.` : 'Pastikan karyawan dan periode belum pernah dicatat.'}>
      <form key={editing?.id ?? 'new'} className="modal-form" onSubmit={submit}>
        <Field label="Karyawan" name="employeeId" required><select name="employeeId" value={formEmployee} disabled={!!editing} onChange={e => setFormEmployee(e.target.value)}><option value="" disabled>Pilih karyawan</option>{employees.map(person => <option key={person.id} value={person.id}>{person.name} · {person.role}</option>)}</select></Field>
        <div className="form-row"><Field label="Periode gaji" name="period" type="month" required value={formPeriod} onChange={e => setFormPeriod(e.target.value)} /><Field label="Jumlah pembayaran" name="amount" type="number" min={1} required placeholder="0" defaultValue={editing?.amount} /></div>
        <div className="form-row"><Field label="Tanggal pembayaran" name="paymentDate" type="date" required defaultValue={editing?.paymentDate || today()} /><Field label="Status" name="status" required><select name="status" defaultValue={editing?.status || 'paid'}><option value="paid">Lunas</option><option value="pending">Menunggu pembayaran</option></select></Field></div>
        {duplicate && <div className="duplicate-notice"><CircleAlert size={16} /><span>Pembayaran karyawan ini untuk periode tersebut sudah tercatat. Pilih periode lain.</span></div>}
        {errorMessage && <div className="duplicate-notice" role="alert"><CircleAlert size={16} /><span>{errorMessage}</span></div>}
        <div className="modal-actions"><Button variant="secondary" onClick={closeModal}>Batal</Button><Button type="submit" disabled={saving || duplicate || !formEmployee}>{saving ? 'Menyimpan…' : editing ? 'Simpan perubahan' : 'Simpan pembayaran'}</Button></div>
      </form>
    </Modal>
  </div>;
}

function ExpensesPage() {
  const q = useGetExpenses({ query: { queryKey: getGetExpensesQueryKey() } }); const qc = useQueryClient(); const create = useCreateExpense(); const [modal, setModal] = useState(false); const [formError, setFormError] = useState('');
  const submit = (e: React.FormEvent<HTMLFormElement>) => { e.preventDefault(); const d = new FormData(e.currentTarget); const expenseType = String(d.get('expenseType')) as 'operational' | 'inventory'; create.mutate({ data: { category: String(d.get('category')), description: String(d.get('description')).trim(), amount: Number(d.get('amount')), date: String(d.get('date')), expenseType } }, { onSuccess: () => { qc.invalidateQueries({ queryKey: getGetExpensesQueryKey() }); qc.invalidateQueries({ queryKey: getGetKasirDashboardQueryKey() }); qc.invalidateQueries({ queryKey: getGetReportsQueryKey() }); setFormError(''); setModal(false); }, onError: error => setFormError(errorText(error, 'Pengeluaran belum tersimpan. Periksa data dan coba lagi.')) }); };
  const expenses = q.data || [];
  const realExpenses = expenses.filter(item => !item.isDemo);
  const isInventoryExpense = (item: NonNullable<typeof expenses[number]>) => item.expenseType === 'inventory' || (!item.expenseType && /bahan baku|pembelian bahan|persediaan/i.test(`${item.category} ${item.description}`));
  return <div className="page-enter"><Heading eyebrow="KEUANGAN • BIAYA" title="Pengeluaran" subtitle="Catat biaya operasional agar arus kas usaha tetap terpantau." action={<Button onClick={() => setModal(true)}><Plus size={16} /> Catat pengeluaran</Button>} />
    <div className="inline-summary"><div><ArrowDownLeft size={17} /><span>Pengeluaran nyata tercatat</span><b data-testid="expenses-total">{rupiah(realExpenses.reduce((sum, item) => sum + item.amount, 0))}</b></div><div><ClipboardList size={17} /><span>Jumlah catatan</span><b>{expenses.length}</b></div><div><span>Biaya operasional</span><b>{rupiah(realExpenses.filter(item => !isInventoryExpense(item)).reduce((sum, item) => sum + item.amount, 0))}</b></div></div>
    <div className="inline-notice" data-testid="expense-accounting-note">Pembelian bahan dicatat sebagai persediaan dan tidak dihitung ulang sebagai biaya operasional. Catatan DEMO dikecualikan dari total keuangan.</div>
    <Panel title="Riwayat pengeluaran" subtitle="Pisahkan biaya operasional dari pembelian persediaan"><QueryState loading={q.isLoading} error={q.isError} empty={!q.isLoading && !q.isError && expenses.length === 0}>{expenses.length ? <div className="table-scroll"><table><thead><tr><th>Tanggal</th><th>Jenis</th><th>Kategori</th><th>Keterangan</th><th>Jumlah</th></tr></thead><tbody>{expenses.map(item => <tr key={item.id} data-testid={`row-expense-${item.id}`}><td>{dateLabel(item.date)}</td><td><span className={`badge ${isInventoryExpense(item) ? 'badge-neutral' : 'badge-green'}`}>{isInventoryExpense(item) ? 'Pembelian bahan' : 'Operasional'} </span></td><td><span className="category-tag">{item.category}</span></td><td>{item.description} {item.isDemo && <span className="badge badge-demo">DEMO</span>}</td><td className="cell-strong">{rupiah(item.amount)}</td></tr>)}</tbody></table></div> : null}</QueryState></Panel>
    <Modal open={modal} onClose={() => { setModal(false); setFormError(''); }} title="Catat pengeluaran" subtitle="Pilih jenis transaksi agar pembelian bahan tidak terhitung ulang."><form className="modal-form" onSubmit={submit}><Field label="Jenis pengeluaran" name="expenseType" required><select name="expenseType" data-testid="select-expense-type"><option value="operational">Operasional</option><option value="inventory">Pembelian persediaan / bahan</option></select></Field><Field label="Kategori" name="category" required><select name="category"><option value="Bahan baku">Bahan baku</option><option value="Gaji">Gaji</option><option value="Sewa">Sewa</option><option value="Operasional">Operasional</option><option value="Lainnya">Lainnya</option></select></Field><Field label="Keterangan" name="description" required placeholder="Contoh: Pembelian bahan mingguan" /><div className="form-row"><Field label="Jumlah" name="amount" type="number" min={0} required placeholder="0" /><Field label="Tanggal" name="date" type="date" required defaultValue={today()} /></div>{formError && <div className="duplicate-notice" role="alert">{formError}</div>}<div className="modal-actions"><Button variant="secondary" onClick={() => { setModal(false); setFormError(''); }}>Batal</Button><Button type="submit" disabled={create.isPending}>{create.isPending ? 'Menyimpan…' : 'Simpan pengeluaran'}</Button></div></form></Modal>
  </div>;
}

function ReportsPage() {
  const date = today();
  const month = localMonth();
  const q = useGetReports({ date, month }, { query: { queryKey: getGetReportsQueryKey({ date, month }) } });
  const report = q.data;
  return <div className="page-enter"><Heading eyebrow="ANALISIS • KEUANGAN" title="Laporan usaha" subtitle="Ringkasan performa keuangan harian dan bulanan." action={<span className="period-chip"><CalendarDays size={15} /> Periode berjalan</span>} />
    <QueryState loading={q.isLoading} error={q.isError} empty={!report}>{report && <>
      <div className="report-period"><div className="period-number">01<span>/</span>02</div><div><b>Performa usaha</b><span>Ringkasan harian dan bulanan dari data tercatat</span></div><Activity size={20} /></div>
      <div className="report-grid">
        <section className="report-card daily-report"><div className="report-card-top"><div><span className="report-kicker">HARI INI</span><h2>Ringkasan harian</h2></div><span className="report-symbol"><CalendarDays size={18} /></span></div><div className="report-total"><small>Penjualan nyata</small><strong>{rupiah(report.dailyRevenue)}</strong></div><div className="report-lines"><div><span>Biaya bahan</span><b>{rupiah(report.dailyIngredientCost)}</b></div><div><span>Laba kotor</span><b>{rupiah(report.dailyGrossProfit)}</b></div><div><span>Biaya operasional lainnya</span><b>{rupiah(report.dailyExpenses)}</b></div><div className="report-profit"><span>Laba bersih</span><b data-testid="daily-net-profit">{rupiah(report.dailyProfit)}</b></div></div><div className="report-visual"><span className="daily-pill"><ArrowUpRight size={14} /> Hanya data nyata</span></div></section>
        <section className="report-card monthly-report"><div className="report-card-top"><div><span className="report-kicker">BULAN INI</span><h2>Ringkasan bulanan</h2></div><span className="report-symbol"><FileBarChart2 size={18} /></span></div><div className="report-total"><small>Penjualan nyata</small><strong>{rupiah(report.monthlyRevenue)}</strong></div><div className="report-lines"><div><span>Biaya bahan</span><b>{rupiah(report.monthlyIngredientCost)}</b></div><div><span>Laba kotor</span><b>{rupiah(report.monthlyGrossProfit)}</b></div><div><span>Biaya operasional lainnya</span><b>{rupiah(report.monthlyExpenses)}</b></div><div className="report-profit"><span>Laba bersih</span><b data-testid="monthly-net-profit">{rupiah(report.monthlyProfit)}</b></div></div><div className="report-visual report-visual-month"><span className="daily-pill"><Check size={14} /> Rekap bulan berjalan</span></div></section>
      </div>
      <div className="inline-notice" data-testid="report-accounting-note">Pembelian bahan tidak dihitung lagi sebagai biaya operasional. Data DEMO dikecualikan; laba dapat bernilai negatif.</div>
      <Panel title="Komposisi keuangan" subtitle="Perbandingan pemasukan dan pengeluaran pada periode ini"><div className="compare-list">{[{ label: 'Hari ini', revenue: report.dailyRevenue, expenses: report.dailyExpenses }, { label: 'Bulan ini', revenue: report.monthlyRevenue, expenses: report.monthlyExpenses }].map(row => <div className="compare-row" key={row.label}><div className="compare-title"><b>{row.label}</b><span>Pemasukan <strong>{rupiah(row.revenue)}</strong></span><span>Pengeluaran <strong>{rupiah(row.expenses)}</strong></span></div><div className="compare-bars"><div className="compare-bar revenue-bar"><i style={{ width: `${row.revenue ? Math.max(4, row.revenue / Math.max(row.revenue, row.expenses, 1) * 100) : 0}%` }} /></div><div className="compare-bar expense-bar"><i style={{ width: `${row.expenses ? Math.max(4, row.expenses / Math.max(row.revenue, row.expenses, 1) * 100) : 0}%` }} /></div></div></div>)}</div><div className="legend"><span><i className="legend-revenue" /> Pemasukan</span><span><i className="legend-expense" /> Pengeluaran</span></div></Panel>
    </>}</QueryState>
  </div>;
}

function Router() {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}><Shell><Switch>
    <Route path="/" component={DashboardPage} />
    <Route path="/food-cost" component={FoodCostPage} />
    <Route path="/orders" component={OrdersPage} />
    <Route path="/inventory" component={InventoryPage} />
    <Route path="/employees" component={EmployeesPage} />
    <Route path="/payroll" component={PayrollPage} />
    <Route path="/expenses" component={ExpensesPage} />
    <Route path="/reports" component={ReportsPage} />
    <Route component={NotFound} />
  </Switch></Shell></ErrorBoundary>;
}

function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Router /></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}

export default App;
